# **5. Het Worker Ecosysteem: Van Pijplijn naar Event-Driven Architectuur**

Versie: 3.1 (Configureerbare Workflow Orkestratie)  
Status: Definitief  
Datum: 2025-10-14

---

## **Inhoudsopgave**

1. [Introductie: De Paradigma Shift](#51-introductie-de-paradigma-shift)
   - 1.1 [Van Lineaire Pijplijn naar Event-Driven Ecosysteem](#511-van-lineaire-pijplijn-naar-event-driven-ecosysteem)
   - 1.2 [De Vier Kerncriteria van V3](#512-de-vier-kerncriteria-van-v3)
   - 1.3 [De 5 Worker Categorieën](#513-de-5-worker-categorieën)
2. [Fase 1: Context Phase - "De Cartograaf"](#52-fase-1-context-phase---de-cartograaf)
   - 2.1 [Verantwoordelijkheid](#521-verantwoordelijkheid)
   - 2.2 [Worker Types](#522-worker-types)
   - 2.3 [Praktijkvoorbeeld](#523-praktijkvoorbeeld)
3. [Fase 2A: Opportunity Detection - "De Verkenner"](#53-fase-2a-opportunity-detection---de-verkenner)
   - 3.1 [Verantwoordelijkheid](#531-verantwoordelijkheid)
   - 3.2 [Worker Types](#532-worker-types)
   - 3.3 [Parallelle Verwerking](#533-parallelle-verwerking)
   - 3.4 [Praktijkvoorbeeld](#534-praktijkvoorbeeld)
4. [Fase 2B: Threat Detection - "De Waakhond" (Parallel)](#54-fase-2b-threat-detection---de-waakhond-parallel)
   - 4.1 [Verantwoordelijkheid](#541-verantwoordelijkheid)
   - 4.2 [Worker Types](#542-worker-types)
   - 4.3 [Parallelle Verwerking met Opportunities](#543-parallelle-verwerking-met-opportunities)
   - 4.4 [Praktijkvoorbeeld](#544-praktijkvoorbeeld)
5. [Fase 3: Planning Phase - "De Strateeg"](#55-fase-3-planning-phase---de-strateeg)
   - 5.1 [Verantwoordelijkheid](#551-verantwoordelijkheid)
   - 5.2 [De Vier Planning Sub-Fases](#552-de-vier-planning-sub-fases)
   - 5.3 [Planning Sub-Fases Gedetailleerd](#553-planning-sub-fases-gedetailleerd)
   - 5.4 [Praktijkvoorbeeld](#554-praktijkvoorbeeld)
6. [Fase 4: Execution Phase - "De Uitvoerder"](#56-fase-4-execution-phase---de-uitvoerder)
   - 6.1 [Verantwoordelijkheid](#561-verantwoordelijkheid)
   - 6.2 [Worker Types](#562-worker-types)
   - 6.3 [Praktijkvoorbeeld](#563-praktijkvoorbeeld)
7. [Event-Driven Workflow: Drie Abstractieniveaus](#57-event-driven-workflow-drie-abstractieniveaus)
   - 7.1 [Het Probleem](#571-het-probleem)
   - 7.2 [Niveau 1: Impliciete Pijplijnen](#572-niveau-1-impliciete-pijplijnen-95-van-gebruik)
   - 7.3 [Niveau 2: Predefined Triggers](#573-niveau-2-predefined-triggers-opt-in)
   - 7.4 [Niveau 3: Custom Event Chains](#574-niveau-3-custom-event-chains-expert-mode)
   - 7.5 [Event Chain Validatie](#575-event-chain-validatie)
8. [Rolverdeling: Operators & Event Routing](#58-rolverdeling-operators--event-routing)
   - 8.1 [De Vijf Operators](#581-de-vijf-operators)
   - 8.2 [Event Routing Mechanisme](#582-event-routing-mechanisme)
   - 8.3 [Twee Niveaus van Orkestratie](#583-twee-niveaus-van-orkestratie)
9. [Feedback Loops & Causale Traceerbaarheid](#59-feedback-loops--causale-traceerbaarheid)
   - 9.1 [De Technische Feedback Loop](#591-de-technische-feedback-loop-real-time)
   - 9.2 [De Strategische Feedback Loop](#592-de-strategische-feedback-loop-human-in-the-loop)
   - 9.3 [Causale Traceerbaarheid Framework](#593-causale-traceerbaarheid-framework)
10. [Samenvatting: De Paradigma Shift](#510-samenvatting-de-paradigma-shift)
    - 10.1 [Wat is er Veranderd?](#5101-wat-is-er-veranderd)
    - 10.2 [Kernvoordelen](#5102-kernvoordelen)
    - 10.3 [Migratie Pad](#5103-migratie-pad)
11. [Volgende Stappen](#511-volgende-stappen)

---

## **Executive Summary**

Dit document beschrijft de fundamentele transformatie van S1mpleTrader van een rigide lineaire pijplijn naar een flexibel, configureerbaar workflow orkestratiesysteem. De vier kernprincipes van V3:

### **1. Van Lineaire Pijplijn naar Parallel Event-Driven Ecosysteem**

V2 was een 9-fasen sequentiële pijplijn. V3 is een 5-fase parallel systeem waar Opportunities en Threats simultaan worden gedetecteerd, waardoor snellere responstijden en betere risicobeheersing mogelijk zijn.

### **2. Configureerbare Orkestratie (Niet Hard-Coded)**

Operators zijn **niet hard-coded parallel of sequentieel**. Hun gedrag wordt bepaald door [`operators.yaml`](config/operators.yaml) configuratie via:
- **ExecutionStrategy**: SEQUENTIAL, PARALLEL, of EVENT_DRIVEN
- **AggregationStrategy**: CHAIN_THROUGH of COLLECT_ALL

Dit maakt het systeem aanpasbaar zonder code-wijzigingen.

### **3. Drie Abstractieniveaus voor Event Workflows**

- **Niveau 1 (Impliciet)**: Definieer alleen workers, systeem genereert events automatisch
- **Niveau 2 (Predefined)**: Gebruik standaard triggers zoals `on_context_ready`, `on_ledger_update`
- **Niveau 3 (Custom)**: Volledige controle met custom events en routing

Deze progressieve complexiteit maakt het systeem toegankelijk voor beginners én krachtig voor experts.

### **4. Hybride Orkestratie: Operators + Events**

Het systeem werkt op twee complementaire niveaus:
- **Primair**: Operators roepen workers aan volgens ExecutionStrategy (configureerbaar gedrag)
- **Secundair**: Events voor cross-operator communicatie (opt-in voor complexe workflows)

**Kernprincipe**: Events zijn niet verplicht - ze zijn een krachtige aanvulling voor geavanceerde use cases, terwijl de basis orkestratie via configureerbare operators verloopt.

---

## **5.1. Introductie: De Paradigma Shift**

### **5.1.1. Van Lineaire Pijplijn naar Event-Driven Ecosysteem**

**V2 (Oud):** Een rigide, 9-fasen lineaire pijplijn waar elke fase sequentieel werd doorlopen:
```
Data → Regime → Structure → Signal → Refine → Entry → Exit → Size → Route → Execute
```

**V3 (Nieuw):** Een flexibel, event-driven ecosysteem met configureerbare orkestratie en intelligente parallelle verwerking:

```mermaid
graph TB
    Data[Ruwe Data] --> Context[Context Phase]
    Context --> ContextReady[ContextReady Event]
    
    ContextReady --> Opportunity[Opportunity Detection]
    ContextReady --> Threat[Threat Detection]
    
    Opportunity --> OpportunitySignal[Opportunity Detected]
    Threat --> ThreatEvent[Threat Detected]
    
    OpportunitySignal --> Planning[Planning Phase]
    ThreatEvent --> Planning
    
    Planning --> PlanReady[Plan Ready]
    PlanReady --> Execution[Execution Phase]
    
    style Opportunity fill:#90EE90
    style Threat fill:#FFB6C1
    style Context fill:#87CEEB
    style Planning fill:#FFD700
    style Execution fill:#FFA500
```

### **5.1.2. De Vier Kerncriteria van V3**

Dit document beschrijft de volledige workflow van data tot handelsactie, gebaseerd op vier fundamentele principes:

1. **Configureerbare Orkestratie** - Operators zijn niet hard-coded parallel of sequentieel, maar configureerbaar via [`operators.yaml`](config/operators.yaml). Workers worden aangeroepen volgens hun ExecutionStrategy (SEQUENTIAL, PARALLEL, of EVENT_DRIVEN) en resultaten worden geaggregeerd volgens de AggregationStrategy (CHAIN_THROUGH of COLLECT_ALL). Zie [`2_ARCHITECTURE.md`](2_ARCHITECTURE.md#27-de-data-gedreven-operator) voor details.

2. **Hybride Orkestratie Model** - Workers communiceren **optioneel** via events (voor complexe workflows), maar de primaire orkestratie gebeurt via Operators die workers aanroepen volgens hun ExecutionStrategy configuratie. Events zijn opt-in, niet verplicht. De meeste workflows werken zonder expliciete event definitie.

3. **Opt-in Complexiteit** - Drie abstractieniveaus (Impliciet → Predefined → Custom) maken het systeem toegankelijk voor beginners én krachtig voor experts.

4. **Causale Traceerbaarheid** - Elke actie is traceerbaar naar zijn oorzaak via een rijk framework van causale IDs (OpportunityID, ThreatID, TradeID, ScheduledID).

### **5.1.3. De 5 Worker Categorieën**

De workflow is opgedeeld in vijf conceptueel verschillende fases, elk beheerd door een gespecialiseerde Operator:

| Fase | Worker Type | Rol | Output |
|------|-------------|-----|--------|
| **1. Context** | [`ContextWorker`](backend/core/base_worker.py:BaseWorker) | "De Cartograaf" - verrijkt data | Verrijkte [`TradingContext`](backend/dtos/state/trading_context.py:TradingContext) |
| **2. Opportunity** | [`OpportunityWorker`](backend/core/base_worker.py:BaseWorker) | "De Verkenner" - detecteert kansen | [`Signal`](backend/dtos/pipeline/signal.py:Signal) DTOs |
| **3. Threat** | [`ThreatWorker`](backend/core/base_worker.py:BaseWorker) | "De Waakhond" - detecteert risico's | [`CriticalEvent`](backend/dtos/execution/critical_event.py:CriticalEvent) DTOs |
| **4. Planning** | [`PlanningWorker`](backend/core/base_worker.py:BaseWorker) | "De Strateeg" - maakt plannen | [`RoutedTradePlan`](backend/dtos/pipeline/routed_trade_plan.py:RoutedTradePlan) DTO |
| **5. Execution** | [`ExecutionWorker`](backend/core/base_worker.py:BaseWorker) | "De Uitvoerder" - voert uit | Directe acties |

**Cruciale Verschuiving:** In V2 waren "Opportunity" en "Planning" gecombineerd in één "AnalysisWorker". V3 scheidt deze verantwoordelijkheden expliciet.

---

## **5.2. Fase 1: Context Phase - "De Cartograaf"**

### **5.2.1. Verantwoordelijkheid**

De Context Phase verrijkt ruwe marktdata met objectieve, beschrijvende informatie. Het creëert een "kaart" van de markt zonder te filteren of te oordelen.

**Kernprincipe:** Objectief en beschrijvend - "Dit is wat er is"

### **5.2.2. Worker Types**

[`ContextWorker`](backend/core/base_worker.py:BaseWorker) plugins zijn georganiseerd in 7 sub-types volgens [`ContextType`](backend/core/enums.py:ContextType):

1. **Regime Classification** - Markt regime & conditie classificatie
2. **Structural Analysis** - Technische structuren (swings, zones)
3. **Indicator Calculation** - Technische indicatoren
4. **Microstructure Analysis** - Orderbook & liquiditeit
5. **Temporal Context** - Sessies, tijd patronen
6. **Sentiment Enrichment** - Nieuws, social media
7. **Fundamental Enrichment** - On-chain, economische data

### **5.2.3. Praktijkvoorbeeld**

**Use Case:** ICT/SMC Strategie

```yaml
# strategy_blueprint.yaml
workforce:
  context_workers:
    # Structurele analyse
    - plugin: "market_structure_detector"
      subtype: "structural_analysis"
      params:
        detect_bos: true
        detect_choch: true
    
    # Indicatoren
    - plugin: "ema_detector"
      subtype: "indicator_calculation"
      params:
        periods: [20, 50, 200]
    
    # Regime classificatie
    - plugin: "adx_regime_classifier"
      subtype: "regime_classification"
      params:
        adx_threshold: 25
```

**Input:** Ruwe OHLCV [`DataFrame`](backend/dtos/state/trading_context.py:TradingContext.ohlcv_df)

**Proces:** Elke worker voegt kolommen toe aan de DataFrame:
- `market_structure_detector` → `trend_direction`, `is_bos`, `is_choch`
- `ema_detector` → `ema_20`, `ema_50`, `ema_200`
- `adx_regime_classifier` → `regime` ('trending' of 'ranging')

**Output:** Verrijkte [`enriched_df`](backend/dtos/state/trading_context.py:TradingContext.enriched_df) in het [`TradingContext`](backend/dtos/state/trading_context.py:TradingContext) object

**Event:** Publiceert `ContextReady` event wanneer voltooid

---

## **5.3. Fase 2A: Opportunity Detection - "De Verkenner"**

### **5.3.1. Verantwoordelijkheid**

De Opportunity Detection Phase herkent handelskansen op basis van patronen, theorieën en strategieën. Het genereert "handelsideeën" zonder concrete plannen te maken.

**Kernprincipe:** Probabilistisch en creatief - "Ik zie een mogelijkheid"

### **5.3.2. Worker Types**

[`OpportunityWorker`](backend/core/base_worker.py:BaseWorker) plugins zijn georganiseerd in 7 sub-types volgens [`OpportunityType`](backend/core/enums.py:OpportunityType):

1. **Technical Pattern** - Patroonherkenning (FVG, breakouts)
2. **Momentum Signal** - Trend following signalen
3. **Mean Reversion** - Oversold/overbought detectie
4. **Statistical Arbitrage** - Arbitrage opportuniteiten
5. **Event Driven** - Nieuws-gebaseerde signalen
6. **Sentiment Signal** - Sentiment extremen
7. **ML Prediction** - Machine learning voorspellingen

### **5.3.3. Parallelle Verwerking**

**Cruciale Verschuiving:** Opportunity workers worden standaard **parallel** uitgevoerd volgens de ExecutionStrategy configuratie in [`operators.yaml`](config/operators.yaml). Alle opportunity workers ontvangen dezelfde [`TradingContext`](backend/dtos/state/trading_context.py:TradingContext) en genereren hun signalen onafhankelijk.

```mermaid
graph LR
    Context[TradingContext] --> Op1[FVG Detector]
    Context --> Op2[Breakout Scanner]
    Context --> Op3[Divergence Finder]
    
    Op1 --> Signal1[Signal 1]
    Op2 --> Signal2[Signal 2]
    Op3 --> Signal3[Signal 3]
    
    Signal1 --> Planning[Planning Phase]
    Signal2 --> Planning
    Signal3 --> Planning
    
    style Op1 fill:#90EE90
    style Op2 fill:#90EE90
    style Op3 fill:#90EE90
```

### **5.3.4. Praktijkvoorbeeld**

**Use Case:** ICT FVG Entry Detection

```yaml
opportunity_workers:
  - plugin: "fvg_entry_detector"
    subtype: "technical_pattern"
    params:
      min_gap_size: 5
      require_structure_break: true
  
  - plugin: "volume_spike_refiner"
    subtype: "technical_pattern"
    params:
      min_volume_percentile: 80
```

**Input:** Verrijkte [`TradingContext`](backend/dtos/state/trading_context.py:TradingContext) (met `is_bos`, `trend_direction`, etc.)

**Proces:**
1. `fvg_entry_detector` scant voor Fair Value Gaps na een structure break
2. `volume_spike_refiner` valideert volume op het signaal moment

**Output:** [`Signal`](backend/dtos/pipeline/signal.py:Signal) DTOs met unieke `opportunity_id`:

```python
Signal(
    opportunity_id=uuid4(),  # Causale ID
    timestamp="2025-10-14T10:00:00Z",
    asset="BTC/EUR",
    direction="long",
    signal_type="fvg_entry",
    metadata={"gap_size": 8.5, "volume_percentile": 85}
)
```

**Event:** Publiceert `SignalGenerated` events per signaal

---

## **5.4. Fase 2B: Threat Detection - "De Waakhond" (Parallel)**

### **5.4.1. Verantwoordelijkheid**

De Threat Detection Phase draait **parallel** aan Opportunity Detection en monitort risico's, bedreigingen en afwijkingen. Het publiceert waarschuwende events maar handelt **nooit zelf**.

**Kernprincipe:** Defensief en informatief - "Let op, hier is een risico"

### **5.4.2. Worker Types**

[`ThreatWorker`](backend/core/base_worker.py:BaseWorker) plugins zijn georganiseerd in 5 sub-types volgens [`ThreatType`](backend/core/enums.py:ThreatType):

1. **Portfolio Risk** - Drawdown, exposure, correlatie
2. **Market Risk** - Volatiliteit, liquiditeit
3. **System Health** - Connectie, data kwaliteit
4. **Strategy Performance** - Underperformance, drift
5. **External Event** - Breaking news, regulatie

### **5.4.3. Parallelle Verwerking met Opportunities**

```mermaid
graph TB
    Context[ContextReady Event] --> Fork{Event Bus}
    
    Fork --> OpOp[OpportunityOperator]
    Fork --> ThreatOp[ThreatOperator]
    
    OpOp --> Op1[FVG Detector]
    OpOp --> Op2[Breakout Scanner]
    
    ThreatOp --> T1[Max Drawdown Monitor]
    ThreatOp --> T2[Volatility Spike Detector]
    
    Op1 --> OpSignal[Opportunity Signals]
    Op2 --> OpSignal
    
    T1 --> ThreatEvent[Threat Events]
    T2 --> ThreatEvent
    
    OpSignal --> Planning[Planning Phase]
    ThreatEvent --> Planning
    
    style OpOp fill:#90EE90
    style ThreatOp fill:#FFB6C1
```

### **5.4.4. Praktijkvoorbeeld**

**Use Case:** Risk Management voor Trading Strategie

```yaml
threat_workers:
  - plugin: "max_drawdown_monitor"
    subtype: "portfolio_risk"
    triggers:
      - "on_ledger_update"  # Predefined trigger
    params:
      max_daily_drawdown: 2.0
      max_total_drawdown: 10.0
  
  - plugin: "volatility_spike_detector"
    subtype: "market_risk"
    triggers:
      - "on_context_ready"
    params:
      volatility_threshold_percentile: 95
```

**Input:** 
- [`StrategyLedger`](backend/core/strategy_ledger.py) (voor portfolio risk)
- Verrijkte [`TradingContext`](backend/dtos/state/trading_context.py:TradingContext) (voor market risk)

**Output:** [`CriticalEvent`](backend/dtos/execution/critical_event.py:CriticalEvent) DTOs met unieke `threat_id`:

```python
CriticalEvent(
    threat_id=uuid4(),  # Causale ID
    timestamp="2025-10-14T10:00:00Z",
    event_type="MAX_DRAWDOWN_BREACHED",
    severity="HIGH",
    metadata={
        "current_drawdown": 2.5,
        "max_allowed": 2.0,
        "recommendation": "HALT_NEW_TRADES"
    }
)
```

**Event:** Publiceert `ThreatDetected` events

---

## **5.5. Fase 3: Planning Phase - "De Strateeg"**

### **5.5.1. Verantwoordelijkheid**

De Planning Phase transformeert opportunities naar concrete, uitvoerbare plannen. Het luistert naar **beide** Opportunity signals én Threat events om intelligente beslissingen te maken.

**Kernprincipe:** Deterministisch en tactisch - "Gegeven deze kans en deze risico's, dit is het plan"

### **5.5.2. De Vier Planning Sub-Fases**

[`PlanningWorker`](backend/core/base_worker.py:BaseWorker) plugins zijn georganiseerd in 4 sequentiële sub-fases volgens [`PlanningPhase`](backend/core/enums.py:PlanningPhase):

```mermaid
graph LR
    Signal[Opportunity Signal] --> Entry[1. Entry Planning]
    Entry --> Exit[2. Exit Planning]
    Exit --> Size[3. Size Planning]
    Size --> Route[4. Order Routing]
    Route --> Plan[Routed Trade Plan]
    
    Threats[Threat Events] -.->|Beïnvloeden| Entry
    Threats -.->|Beïnvloeden| Exit
    Threats -.->|Beïnvloeden| Size
    
    style Entry fill:#FFD700
    style Exit fill:#FFD700
    style Size fill:#FFD700
    style Route fill:#FFD700
    style Threats fill:#FFB6C1,stroke-dasharray: 5 5
```

### **5.5.3. Planning Sub-Fases Gedetailleerd**

#### **5.5.3.1. Entry Planning**

**Doel:** Bepaal de precieze entry prijs en methode.

**Voorbeelden:**
- `limit_entry_at_fvg` - Limit order op FVG midpoint
- `market_entry_immediate` - Direct market order
- `twap_entry` - Verdeeld over tijd

**Input:** [`Signal`](backend/dtos/pipeline/signal.py:Signal)  
**Output:** [`EntrySignal`](backend/dtos/pipeline/entry_signal.py:EntrySignal) (Signal + entry_price)

#### **5.5.3.2. Exit Planning**

**Doel:** Bepaal stop-loss en take-profit niveaus.

**Voorbeelden:**
- `liquidity_target_exit` - Stops bij liquidity zones
- `atr_based_stops` - Stops op basis van ATR
- `fixed_rr_exit` - Fixed Risk:Reward ratio

**Input:** [`EntrySignal`](backend/dtos/pipeline/entry_signal.py:EntrySignal)  
**Output:** [`RiskDefinedSignal`](backend/dtos/pipeline/risk_defined_signal.py:RiskDefinedSignal) (EntrySignal + sl_price + tp_price)

#### **5.5.3.3. Size Planning**

**Doel:** Bepaal positiegrootte op basis van risico en kapitaal.

**Threats Invloed:** Als `MAX_DRAWDOWN_BREACHED` gedetecteerd → reduce size of skip

**Voorbeelden:**
- `fixed_risk_sizer` - Fixed % risico per trade
- `kelly_criterion_sizer` - Kelly criterion sizing
- `adaptive_sizer` - Past aan op basis van threat events

**Input:** [`RiskDefinedSignal`](backend/dtos/pipeline/risk_defined_signal.py:RiskDefinedSignal) + Threat events  
**Output:** [`TradePlan`](backend/dtos/pipeline/trade_plan.py:TradePlan) (RiskDefinedSignal + position_size)

#### **5.5.3.4. Order Routing**

**Doel:** Vertaal het strategische plan naar tactische executie-instructies.

**Voorbeelden:**
- `limit_order_router` - Limit orders
- `iceberg_router` - Verberg grote orders
- `smart_router` - Intelligent order routing

**Input:** [`TradePlan`](backend/dtos/pipeline/trade_plan.py:TradePlan)  
**Output:** [`RoutedTradePlan`](backend/dtos/pipeline/routed_trade_plan.py:RoutedTradePlan) (TradePlan + order_type + routing params)

### **5.5.4. Praktijkvoorbeeld**

```yaml
planning_workers:
  entry_planning:
    - plugin: "limit_entry_at_fvg"
      params:
        entry_at_midpoint: true
  
  exit_planning:
    - plugin: "liquidity_target_exit"
      params:
        stop_below_order_block: true
        target_opposite_liquidity: true
  
  size_planning:
    - plugin: "adaptive_risk_sizer"
      params:
        base_risk_percent: 1.0
        reduce_on_high_threat: true  # Reageert op Threat events!
  
  order_routing:
    - plugin: "limit_order_router"
```

**DTO Evolutie:**

```
Signal (opportunity_id)
  ↓
EntrySignal (opportunity_id, entry_price: 50000.00)
  ↓
RiskDefinedSignal (opportunity_id, entry: 50000, sl: 49500, tp: 51000)
  ↓
TradePlan (opportunity_id, ..., position_size: 0.02 BTC)
  ↓
RoutedTradePlan (opportunity_id, ..., order_type: "limit", tif: "GTC")
```

**Causale Traceerbaarheid:** Alle DTOs behouden de originele `opportunity_id` voor volledige traceerbaarheid.

---

## **5.6. Fase 4: Execution Phase - "De Uitvoerder"**

### **5.6.1. Verantwoordelijkheid**

De Execution Phase voert plannen uit en beheert actieve posities dynamisch. Het reageert op triggers (tijd, events, markt).

**Kernprincipe:** Actief en deterministisch - "Ik voer uit en beheer"

### **5.6.2. Worker Types**

[`ExecutionWorker`](backend/core/base_worker.py:BaseWorker) plugins zijn georganiseerd in 4 sub-types volgens [`ExecutionType`](backend/core/enums.py:ExecutionType):

1. **Trade Initiation** - Het initiëren van nieuwe trades
2. **Position Management** - Dynamisch beheer van lopende posities
3. **Risk Safety** - Noodmaatregelen en circuit breakers
4. **Operational** - Geplande, operationele taken (DCA, rebalancing)

### **5.6.3. Praktijkvoorbeeld**

```yaml
execution_workers:
  trade_initiation:
    - plugin: "default_plan_executor"
  
  position_management:
    - plugin: "trailing_stop_manager"
      params:
        trail_after_first_target: true
        trail_by_structure: true
    
    - plugin: "partial_profit_taker"
      params:
        take_50_percent_at_first_target: true
        move_stop_to_breakeven: true
  
  risk_safety:
    - plugin: "emergency_exit_agent"
      triggers:
        - "on_threat_detected"  # Reageert op Threat events!
      params:
        exit_on_severity: ["CRITICAL", "HIGH"]
  
  operational:
    - plugin: "weekly_dca_executor"
      triggers:
        - "on_schedule:weekly_dca"
```

**Threat Integration:** De `emergency_exit_agent` luistert naar `ThreatDetected` events en kan posities forceren te sluiten bij kritieke risico's.

---

## **5.7. Event-Driven Workflow: Drie Abstractieniveaus**

### **5.7.1. Het Probleem**

Een volledig event-driven systeem biedt maximale flexibiliteit, maar introduceert complexiteit. Hoe maken we dit toegankelijk?

**Oplossing:** Drie progressieve abstractieniveaus die opt-in complexiteit bieden.

### **5.7.2. Niveau 1: Impliciete Pijplijnen (95% van gebruik)**

**Voor wie:** Standaard quant die een lineaire strategie wil bouwen.

**Hoe:** Definieer alleen de workers - het systeem genereert automatisch de event chain.

**Voorbeeld:**

```yaml
# strategy_blueprint.yaml
workforce:
  context_workers:
    - plugin: "ema_detector"
    - plugin: "market_structure_detector"
  
  opportunity_workers:
    - plugin: "fvg_detector"
  
  planning_workers:
    entry_planning:
      - plugin: "limit_entry_planner"
    exit_planning:
      - plugin: "liquidity_target_exit"
    size_planning:
      - plugin: "fixed_risk_sizer"
    order_routing:
      - plugin: "default_router"
  
  execution_workers:
    trade_initiation:
      - plugin: "default_plan_executor"
```

**Automatisch gegenereerde event flow:**

```mermaid
graph LR
    MD[MarketDataReceived] --> CR[ContextReady]
    CR --> SG[SignalGenerated]
    SG --> PR[PlanReady]
    PR --> EA[ExecutionApproved]
```

**Voordelen:**
- ✅ Geen event management nodig
- ✅ Duidelijke, lineaire flow
- ✅ "Het werkt gewoon"

### **5.7.3. Niveau 2: Predefined Triggers (Opt-in)**

**Voor wie:** Quant die specifieke workers op specifieke momenten wil activeren.

**Hoe:** Gebruik predefined trigger namen voor common use cases.

**Voorbeeld:**

```yaml
workforce:
  context_workers:
    - plugin: "ema_detector"
  
  opportunity_workers:
    - plugin: "fvg_detector"
  
  threat_workers:
    - plugin: "max_drawdown_monitor"
      triggers:
        - "on_ledger_update"  # Predefined
    
    - plugin: "news_event_monitor"
      triggers:
        - "on_context_ready"  # Predefined
```

**Predefined Triggers:**

| Trigger | Wanneer | Type |
|---------|---------|------|
| `on_context_ready` | Na Context Phase | Event |
| `on_signal_generated` | Per opportunity signal | Event |
| `on_ledger_update` | Bij ledger wijziging | Event |
| `on_position_opened` | Bij nieuwe positie | Event |
| `on_position_closed` | Bij gesloten positie | Event |
| `on_schedule` | Tijd-gebaseerd | Scheduler |

**Voordelen:**
- ✅ Meer controle waar nodig
- ✅ Geen custom event namen
- ✅ Duidelijke, gedocumenteerde opties

### **5.7.4. Niveau 3: Custom Event Chains (Expert Mode)**

**Voor wie:** Geavanceerde quant die complexe, event-driven workflows wil bouwen.

**Hoe:** Definieer custom events en hun routing expliciet.

**Voorbeeld: Smart DCA (Volledige Use Case)**

```yaml
# strategy_blueprint.yaml - Smart DCA Strategy
name: "Smart_DCA_BTC"
version: "1.0.0"

workforce:
  # === CONTEXT ===
  context_workers:
    - plugin: "regime_classifier"
      subtype: "regime_classification"
    
    - plugin: "premium_discount_detector"
      subtype: "indicator_calculation"
    
    - plugin: "volatility_percentile_calculator"
      subtype: "indicator_calculation"
  
  # === OPPORTUNITY (Event-Aware) ===
  opportunity_workers:
    - plugin: "dca_opportunity_scorer"
      subtype: "technical_pattern"
      triggers:
        - "on_schedule:weekly_dca"  # Scheduler trigger
      publishes:
        - event: "dca_opportunity_scored"
          payload_type: "Signal"
      params:
        score_regime: true
        score_price_zone: true
        score_volatility: true
  
  # === THREAT (Event-Aware, Parallel) ===
  threat_workers:
    - plugin: "dca_risk_assessor"
      subtype: "portfolio_risk"
      triggers:
        - "on_schedule:weekly_dca"  # Same trigger, parallel!
      publishes:
        - event: "dca_risk_assessed"
          payload_type: "CriticalEvent"
      params:
        max_drawdown_for_dca: 15.0
        max_volatility_percentile: 95
  
  # === PLANNING (Event-Aware) ===
  planning_workers:
    entry_planning:
      - plugin: "adaptive_dca_planner"
        triggers:
          - "dca_opportunity_scored"
          - "dca_risk_assessed"
        requires_all: true  # Wacht op BEIDE events!
        publishes:
          - event: "dca_plan_ready"
            payload_type: "TradePlan"
        params:
          base_amount: 1000
          min_amount: 500
          max_amount: 2000
  
  # === EXECUTION ===
  execution_workers:
    operational:
      - plugin: "dca_plan_executor"
        triggers:
          - "dca_plan_ready"
```

**Scheduler Configuratie:**

```yaml
# schedule.yaml
schedules:
  - name: "weekly_dca"
    cron: "0 10 * * 1"  # Elke maandag 10:00
    event: "WEEKLY_DCA_TICK"
```

**Event Flow Diagram:**

```mermaid
graph TB
    Scheduler[Scheduler: WEEKLY_DCA_TICK] --> Fork{Event Bus}
    
    Fork --> OpScorer[DCA Opportunity Scorer]
    Fork --> RiskAssessor[DCA Risk Assessor]
    
    OpScorer --> OpEvent[dca_opportunity_scored]
    RiskAssessor --> RiskEvent[dca_risk_assessed]
    
    OpEvent --> Planner[Adaptive DCA Planner]
    RiskEvent --> Planner
    
    Planner -->|Waits for BOTH| PlanEvent[dca_plan_ready]
    PlanEvent --> Executor[DCA Plan Executor]
    
    Executor --> Action[Execute DCA Purchase]
    
    style OpScorer fill:#90EE90
    style RiskAssessor fill:#FFB6C1
    style Planner fill:#FFD700
    style Executor fill:#FFA500
```

**Beslissingsmatrix in Planner:**

| Opportunity Score | Risk Level | Action |
|-------------------|------------|--------|
| 80+ | LOW | Max amount (€2000) |
| 60-79 | LOW | Base amount (€1000) |
| <60 | LOW | Min amount (€500) |
| 70+ | MEDIUM | Base amount (€1000) |
| <70 | MEDIUM | Min amount (€500) |
| Any | HIGH | Skip DCA this week |

**Voordelen:**
- ✅ Volledige controle over workflow
- ✅ Complexe, intelligente strategieën mogelijk
- ✅ Workers blijven simpel en testbaar
- ✅ Intelligentie komt van compositie, niet van plugin code

### **5.7.5. Event Chain Validatie**

Het systeem valideert automatisch event chains tijdens blueprint loading:

**Validatie Checks:**

1. **Trigger heeft Publisher** - Elke trigger moet door iemand gepubliceerd worden
2. **Geen Circular Dependencies** - Geen circulaire event loops
3. **Type Matching** - Payload types moeten matchen
4. **Dead Ends Warning** - Waarschuwing als event niet wordt geconsumeerd

**Voorbeeld Validatie Error:**

```
ValidationError: Worker 'adaptive_dca_planner' luistert naar event 
'dca_opportunity_scored', maar geen enkele worker publiceert dit event!

Tip: Voeg een worker toe met:
  publishes:
    - event: "dca_opportunity_scored"
```

---

## **5.8. Rolverdeling: Operators & Event Routing**

### **5.8.1. De Vijf Operators**

Elke worker categorie wordt beheerd door een gespecialiseerde Operator:

| Operator | Beheert | Execution Strategy | Aggregation Strategy |
|----------|---------|-------------------|---------------------|
| [`ContextOperator`](backend/core/operators/base_operator.py:BaseOperator) | [`ContextWorker`](backend/core/base_worker.py:BaseWorker) | SEQUENTIAL | CHAIN_THROUGH |
| [`OpportunityOperator`](backend/core/operators/base_operator.py:BaseOperator) | [`OpportunityWorker`](backend/core/base_worker.py:BaseWorker) | PARALLEL | COLLECT_ALL |
| [`ThreatOperator`](backend/core/operators/base_operator.py:BaseOperator) | [`ThreatWorker`](backend/core/base_worker.py:BaseWorker) | PARALLEL | COLLECT_ALL |
| [`PlanningOperator`](backend/core/operators/base_operator.py:BaseOperator) | [`PlanningWorker`](backend/core/base_worker.py:BaseWorker) | SEQUENTIAL | CHAIN_THROUGH |
| [`ExecutionOperator`](backend/core/operators/base_operator.py:BaseOperator) | [`ExecutionWorker`](backend/core/base_worker.py:BaseWorker) | EVENT_DRIVEN | NONE |

**Configuratie:** Operators worden geconfigureerd in [`operators.yaml`](config/operators.yaml), niet hard-coded. Zie [`2_ARCHITECTURE.md`](2_ARCHITECTURE.md#27-de-data-gedreven-operator) voor details over ExecutionStrategy en AggregationStrategy.

### **5.8.2. Event Routing Mechanisme**

**Automatische Routing:**

```python
# Pseudo-code: BaseOperator event routing
class BaseOperator:
    def on_event(self, event_name: str, payload: Any):
        """Route event naar relevante workers."""
        
        # Find workers die luisteren naar dit event
        listening_workers = [
            worker for worker in self.workers
            if event_name in worker.triggers
        ]
        
        # Roep on_event() aan op elke worker
        for worker in listening_workers:
            worker.on_event(event_name, payload)
        
        # Als alle required events binnen zijn, roep process() aan
        if self._all_required_events_received(worker):
            result = worker.process(...)
            
            # Publiceer output events
            for event_config in worker.publishes:
                self.event_bus.publish(event_config.event_name, result)
```

### **5.8.3. Twee Niveaus van Orkestratie**

Het S1mpleTrader V3 systeem werkt op **twee complementaire niveaus** van workflow orkestratie. Dit is een cruciale architectonische keuze die flexibiliteit combineert met eenvoud:

#### **Niveau 1: Operator Configuratie (Primaire Orkestratie)**

**Wat:** Operators bepalen de **basale volgordelijkheid en uitvoeringsstrategie** van workers binnen hun domein.

**Waar:** Geconfigureerd in [`operators.yaml`](config/operators.yaml)

**Hoe:** Via twee parameters:

1. **ExecutionStrategy** - Bepaalt HOE workers worden uitgevoerd:
   - `SEQUENTIAL` - Workers worden één voor één uitgevoerd (output van worker N wordt input van worker N+1)
   - `PARALLEL` - Alle workers ontvangen dezelfde input en draaien simultaan
   - `EVENT_DRIVEN` - Workers reageren op events wanneer die gepubliceerd worden

2. **AggregationStrategy** - Bepaalt HOE outputs worden samengevoegd:
   - `CHAIN_THROUGH` - Output van één worker wordt input voor de volgende (voor SEQUENTIAL)
   - `COLLECT_ALL` - Alle outputs worden verzameld in een lijst (voor PARALLEL)
   - `NONE` - Geen aggregatie (voor EVENT_DRIVEN)

**Voorbeeld Configuratie:**

```yaml
# operators.yaml
operators:
  context_operator:
    execution_strategy: SEQUENTIAL
    aggregation_strategy: CHAIN_THROUGH
    # Context workers bouwen voort op elkaars output
  
  opportunity_operator:
    execution_strategy: PARALLEL
    aggregation_strategy: COLLECT_ALL
    # Alle opportunity workers krijgen dezelfde context
  
  threat_operator:
    execution_strategy: PARALLEL
    aggregation_strategy: COLLECT_ALL
    # Threat detection gebeurt simultaan
  
  planning_operator:
    execution_strategy: SEQUENTIAL
    aggregation_strategy: CHAIN_THROUGH
    # Planning is een stapsgewijze pipeline
  
  execution_operator:
    execution_strategy: EVENT_DRIVEN
    aggregation_strategy: NONE
    # Execution workers reageren op triggers
```

**Voordelen:**
- ✅ Geen code-wijzigingen nodig om gedrag aan te passen
- ✅ Duidelijk, declaratief
- ✅ Geschikt voor 90% van use cases
- ✅ Geen expliciete event definitie nodig

**Beperkingen:**
- ❌ Alle workers binnen een operator volgen dezelfde strategie
- ❌ Geen cross-operator event dependencies mogelijk
- ❌ Beperkt tot voorgedefinieerde execution patterns

#### **Niveau 2: Event Mapping (Optionele Complexiteit)**

**Wat:** Events maken **cross-operator communicatie en complexe workflows** mogelijk die niet passen in de standaard execution strategies.

**Waar:** Geconfigureerd in:
- [`event_map.yaml`](config/event_map.yaml) - Event definities en routing regels
- [`wiring_map.yaml`](config/wiring_map.yaml) - Worker-naar-event mappings
- Of inline in `strategy_blueprint.yaml` via `triggers` en `publishes`

**Wanneer te gebruiken:**
- Een worker in Planning moet reageren op output van zowel Opportunity als Threat (zie Smart DCA)
- Time-based triggers (scheduler events)
- Conditonele workflows (alleen uitvoeren als X EN Y beide waar zijn)
- Custom event chains die niet passen in standaard patterns

**Voorbeeld: Smart DCA (Herhaald)**

```yaml
# Inline in strategy_blueprint.yaml
planning_workers:
  entry_planning:
    - plugin: "adaptive_dca_planner"
      triggers:
        - "dca_opportunity_scored"   # Van Opportunity Operator
        - "dca_risk_assessed"         # Van Threat Operator
      requires_all: true              # Wacht op BEIDE!
      publishes:
        - event: "dca_plan_ready"
```

Dit patroon is **niet mogelijk** met alleen Niveau 1 configuratie omdat:
1. Het vereist input van twee verschillende operators
2. Het heeft conditionele logica (requires_all)
3. Het publiceert custom events

**Voordelen:**
- ✅ Volledige controle over workflow
- ✅ Cross-operator dependencies
- ✅ Complexe, intelligente strategieën
- ✅ Time-based en conditional triggers

**Beperkingen:**
- ❌ Meer configuratie complexity
- ❌ Vereist begrip van event-driven patterns
- ❌ Moet gevalideerd worden (event chains)

#### **Vergelijkingstabel: Niveau 1 vs Niveau 2**

| Aspect | Niveau 1: Operator Config | Niveau 2: Event Mapping |
|--------|--------------------------|-------------------------|
| **Configuratie Locatie** | [`operators.yaml`](config/operators.yaml) | [`event_map.yaml`](config/event_map.yaml), [`wiring_map.yaml`](config/wiring_map.yaml), of inline |
| **Scope** | Binnen één operator | Cross-operator |
| **Execution Control** | ExecutionStrategy (SEQUENTIAL/PARALLEL/EVENT_DRIVEN) | Explicit event triggers |
| **Use Case** | 90% van strategieën | Complexe workflows |
| **Complexity** | Laag - declaratief | Medium - vereist event begrip |
| **Code Changes** | Nooit - pure configuratie | Nooit - pure configuratie |
| **Flexibility** | Beperkt tot predefined patterns | Volledig flexibel |
| **Event Definition** | Impliciete events (auto-gegenereerd) | Expliciete custom events |
| **Cross-Operator Deps** | ❌ Niet mogelijk | ✅ Mogelijk |
| **Conditional Logic** | ❌ Niet mogelijk | ✅ Mogelijk (requires_all, etc.) |
| **Time-Based Triggers** | ❌ Niet direct | ✅ Via scheduler events |
| **Validation** | Auto - compile-time | Event chain validatie nodig |
| **When to Use** | Default - start hier | Opt-in voor advanced needs |

**Architectonisch Principe:**

> "Niveau 1 definieert HOE workers binnen een categorie samenwerken.  
> Niveau 2 definieert WANNEER workers tussen categorieën communiceren."

**Praktisch Advies:**

1. **Start met Niveau 1** - Gebruik alleen operators.yaml voor je eerste strategie
2. **Voeg Niveau 2 toe** wanneer je nodig hebt:
   - Cross-operator dependencies (bijv. Planning reageert op Threat)
   - Time-based triggers (DCA, rebalancing)
   - Conditionele workflows (alleen trade als X én Y)
3. **Combineer beide niveaus** - Gebruik Niveau 1 als basis, Niveau 2 voor specifieke uitzonderingen

**Referenties:**

- Operator ExecutionStrategy details: [`2_ARCHITECTURE.md`](2_ARCHITECTURE.md#27-de-data-gedreven-operator)
- Event workflow examples: Sectie 5.7 in dit document
- Configuratie specs: [`3_DE_CONFIGURATIE_TREIN.md`](3_DE_CONFIGURATIE_TREIN.md)

---

## **5.9. Feedback Loops & Causale Traceerbaarheid**

### **5.9.1. De Technische Feedback Loop (Real-time)**

Deze loop gebeurt ***binnen*** een Operation, via de EventBus:

```mermaid
graph LR
    Context[TradingContext] --> Opportunity[Opportunity Detection]
    Opportunity --> Planning[Planning Phase]
    Planning --> Execution[Execution Phase]
    Execution --> LedgerUpdate[Ledger State Changed]
    LedgerUpdate --> NextContext[Next TradingContext]
    
    style LedgerUpdate fill:#87CEEB
```

**Mechanisme:**
1. ExecutionEnvironment publiceert `LedgerStateChanged` event na elke trade
2. Deze event wordt opgenomen in de volgende [`TradingContext`](backend/dtos/state/trading_context.py:TradingContext)
3. Workers hebben altijd de meest actuele financiële staat beschikbaar

### **5.9.2. De Strategische Feedback Loop (Human-in-the-loop)**

Deze loop vindt plaats ***tussen*** Operations:

```
Operation 1 → Resultaten → Analyse → Blueprint Aanpassing → Operation 2
```

De quant analyseert [`StrategyJournal`](backend/core/strategy_journal.py) data en past de [`strategy_blueprint.yaml`](config/runs/strategy_blueprint.yaml) aan.

### **5.9.3. Causale Traceerbaarheid Framework**

**V3 Shift:** Van simpele `correlation_id` naar rijk causaal ID framework.

**ID Types:**

| ID Type | Gegenereerd Door | Doel |
|---------|------------------|------|
| **OpportunityID** | [`OpportunityWorker`](backend/core/base_worker.py:BaseWorker) | "Waarom is deze trade geopend?" |
| **ThreatID** | [`ThreatWorker`](backend/core/base_worker.py:BaseWorker) | "Waarom is deze trade aangepast/gesloten?" |
| **TradeID** | [`ExecutionWorker`](backend/core/base_worker.py:BaseWorker) | Primaire sleutel in journal |
| **ScheduledID** | Scheduler | "Waarom is deze actie nu uitgevoerd?" |

**Voorbeeld Journal Entry:**

```json
{
  "timestamp": "2025-10-14T10:05:00Z",
  "event_type": "TRADE_OPENED",
  "trade_id": "uuid-789",
  "opportunity_id": "uuid-456",  // Causale link!
  "details": {
    "strategy": "ICT_FVG_Liquidity_Sweep",
    "opportunity_type": "fvg_entry",
    "entry_price": 50000.00,
    "position_size": 0.02
  }
}
```

**Voorbeeld Rejection Entry:**

```json
{
  "timestamp": "2025-10-14T10:00:05Z",
  "event_type": "OPPORTUNITY_REJECTED",
  "opportunity_id": "uuid-123",
  "rejection_reason": {
    "threat_id": "uuid-789",  // Causale link!
    "threat_type": "MAX_DRAWDOWN_BREACHED",
    "details": {
      "current_drawdown": 2.5,
      "max_allowed": 2.0
    }
  }
}
```

**Analyse Mogelijkheden:**
- "Welke opportunities werden het vaakst afgekeurd en waarom?"
- "Welke threat types hadden de meeste impact op performance?"
- "Wat was de gemiddelde tijd tussen opportunity detection en execution?"

---

## **5.10. Samenvatting: De Paradigma Shift**

### **5.10.1. Wat is er Veranderd?**

| Aspect | V2 (Oud) | V3 (Nieuw) |
|--------|----------|------------|
| **Structuur** | Lineaire 9-fasen pijplijn | Event-driven 5-categorie ecosysteem |
| **Verwerking** | Sequentieel | Configureerbaar (SEQUENTIAL/PARALLEL/EVENT_DRIVEN) |
| **Opportunity/Threat** | Geen expliciete scheiding | Parallel detectie met dualiteit |
| **Analysis/Planning** | Gecombineerd | Gescheiden verantwoordelijkheden |
| **Orkestratie** | Hard-coded | Configureerbaar via operators.yaml |
| **Event Model** | Geen | Drie abstractieniveaus + twee orkestratie niveaus |
| **Traceability** | Simpele correlation_id | Rijk causaal ID framework |
| **Flexibiliteit** | Rigide | Opt-in complexiteit |

### **5.10.2. Kernvoordelen**

1. **Conceptuele Zuiverheid** - Elke worker categorie heeft één duidelijke verantwoordelijkheid
2. **Configureerbare Kracht** - Gedrag aanpasbaar via YAML zonder code-wijzigingen
3. **Parallelle Efficiëntie** - Opportunities en Threats worden simultaan gedetecteerd
4. **Intelligente Compositie** - Complexiteit komt van configuratie, niet van plugin code
5. **Causale Transparantie** - Elke actie is traceerbaar naar zijn oorzaak
6. **Progressieve Complexiteit** - Van simpel naar complex zonder refactoring
7. **Methodologie Agnostisch** - Ondersteunt ICT, Wyckoff, ML, DCA, en meer

### **5.10.3. Migratie Pad**

**Backwards Compatibility:** V2 blueprints blijven werken via automatische migratie:

```yaml
# V2 Format (nog steeds ondersteund)
workforce:
  analysis_workers:  # Auto-migrated naar opportunity + planning
    - plugin: "fvg_detector"
      phase: "signal_generation"

# V3 Format (aanbevolen)
workforce:
  opportunity_workers:
    - plugin: "fvg_detector"
      subtype: "technical_pattern"
```

**Migratie Tool:** Gebruik `tools/migrate_v2_to_v3.py` voor automatische conversie.

---

## **5.11. Volgende Stappen**

**Voor Strategie Ontwikkelaars:**
1. Begin met **Niveau 1** (Impliciete Pijplijnen) voor eenvoudige strategieën
2. Upgrade naar **Niveau 2** (Predefined Triggers) voor threat monitoring
3. Gebruik **Niveau 3** (Custom Events) voor complexe workflows zoals Smart DCA

**Voor Plugin Ontwikkelaars:**
1. Lees [`WORKER_TAXONOMIE_V3.md`](docs/development/251014%20Bijwerken%20documentatie/WORKER_TAXONOMIE_V3.md) voor volledige taxonomie
2. Gebruik de juiste base class ([`BaseWorker`](backend/core/base_worker.py:BaseWorker), [`BaseEventAwareWorker`](backend/core/base_worker.py:BaseEventAwareWorker), etc.)
3. Definieer het juiste `type` en `subtype` in je manifest

**Voor Architecten:**
1. Raadpleeg [`MIGRATION_MAP.md`](docs/system/MIGRATION_MAP.md) voor volledige V2→V3 mapping
2. Lees [`2_ARCHITECTURE.md`](docs/system/2_ARCHITECTURE.md) voor architectonische context
3. Review event chain validatie logica in [`ComponentBuilder`](backend/assembly/component_builder.py)
4. Begrijp de twee niveaus van orkestratie (Operator Config vs Event Mapping)

---

**Einde Document v3.1**

*"Van lineaire pijplijn naar configureerbaar ecosysteem - waar operators en events harmonieus samenwerken in een hybride orkestratie model."*