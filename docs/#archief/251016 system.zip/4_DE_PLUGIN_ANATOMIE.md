# **4\. De Anatomie van een Plugin**

Versie: 3.0 (V3 Worker Taxonomie & Gelaagde Capaciteiten)
Status: Definitief
Dit document beschrijft de gedetailleerde structuur en de technische keuzes achter de plugins in de S1mpleTrader V2 architectuur. Plugins zijn de specialistische, onafhankelijke en testbare bouwstenen van elke Operation.
## **Inhoudsopgave**

1. [Executive Summary](#executive-summary)
2. [Fundamentele Mappenstructuur](#41-fundamentele-mappenstructuur)
3. [Formaat Keuzes: YAML vs. JSON](#42-formaat-keuzes-yaml-vs-json)
4. [Het Manifest: De Zelfbeschrijvende ID-kaart](#43-het-manifest-de-zelfbeschrijvende-id-kaart)
   - 4.3.1. [Identification](#431-identification)
   - 4.3.1b. [De 27 Sub-Categorieën](#431b-de-27-sub-categorieën)
   - 4.3.2. [Dependencies (Het Data Contract)](#432-dependencies-het-data-contract)
   - 4.3.3. [Event Configuration (Optioneel)](#433-event-configuration-optioneel---nieuw-in-v3)
   - 4.3.4. [Permissions (Optioneel)](#434-permissions-optioneel)
5. [De Worker & het BaseWorker Raamwerk](#44-de-worker--het-baseworker-raamwerk)
6. [Gelaagde Plugin Capaciteiten](#45-gelaagde-plugin-capaciteiten-nieuw-in-v3)
   - 4.5.1. [Filosofie: De "Glijdende Schaal"](#451-filosofie-de-glijdende-schaal)
   - 4.5.2. [De Ladder van Complexiteit](#452-de-ladder-van-complexiteit)
   - 4.5.3. [Capaciteit 1: State Persistence](#453-capaciteit-1-state-persistence)
   - 4.5.4. [Capaciteit 2: Event Communication](#454-capaciteit-2-event-communication)
   - 4.5.5. [Capaciteit 3: Historical Journaling](#455-capaciteit-3-historical-journaling)
   - 4.5.6. [Combinaties via Multiple Inheritance](#456-combinaties-via-multiple-inheritance)
   - 4.5.7. [Testing Voordelen](#457-testing-voordelen)

---

## **Executive Summary**

Dit document beschrijft de plugin anatomie van S1mpleTrader V2, een modulair systeem gebouwd op vier kernprincipes:

### **🎯 Kernkenmerken**

**1. 5-Categorie Worker Model**
- [`ContextWorker`](backend/core/base_worker.py) - De Cartograaf (marktdata verrijking)
- [`OpportunityWorker`](backend/core/base_worker.py) - De Verkenner (handelskansen herkennen)
- [`ThreatWorker`](backend/core/base_worker.py) - De Waakhond (risico's detecteren)
- [`PlanningWorker`](backend/core/base_worker.py) - De Strateeg (kansen → plannen)
- [`ExecutionWorker`](backend/core/base_worker.py) - De Uitvoerder (plannen uitvoeren)

**2. 27 Sub-Categorieën voor Fijnmazige Classificatie**
- 7 [`ContextTypes`](backend/core/enums.py:ContextType) (regime, structuur, indicatoren, etc.)
- 7 [`OpportunityTypes`](backend/core/enums.py:OpportunityType) (patronen, momentum, mean reversion, etc.)
- 5 [`ThreatTypes`](backend/core/enums.py:ThreatType) (portfolio, markt, systeem risico's)
- 4 [`PlanningPhases`](backend/core/enums.py:PlanningPhase) (entry, exit, sizing, routing)
- 4 [`ExecutionTypes`](backend/core/enums.py:ExecutionType) (initiatie, management, safety, operationeel)

**3. Gelaagde Capabilities (Opt-in Complexiteit)**
```
BaseWorker (90%)           → Pure, stateless logica
BaseStatefulWorker (5%)    → + State persistence
BaseEventAwareWorker (5%)  → + Event communication
BaseJournalingWorker       → + Historical journaling
```

**4. Event-Driven Capaciteiten (Optioneel)**
- 95% van plugins werkt **zonder** events (standaard impliciete pijplijn)
- Event configuratie is volledig **opt-in** voor expert workflows
- Plugin is **zelfstandig verantwoordelijk** voor zijn eigen event configuratie via [`manifest.yaml`](plugins/)

### **🔑 Design Principes**

✅ **Plugin First** - Alles begint bij de plugin  
✅ **Zelfstandig maar Simpel** - Plugin is onafhankelijk, niet complex  
✅ **Opt-in Complexiteit** - Erf alleen wat je nodig hebt  
✅ **Zelfdocumenterend** - Manifest vertelt het hele verhaal  

---


**V3 Architectuur Updates:**
- 5 Worker Categorieën (van 4): Context, Opportunity, Threat, Planning, Execution
- 27 Sub-Categorieën voor fijnmazige classificatie
- Gelaagde Plugin Capaciteiten (opt-in complexiteit)
- Event Configuration support voor expert workflows

## **4.1. Fundamentele Mappenstructuur**

Elke plugin is een opzichzelfstaande Python package. Deze structuur garandeert dat logica, contracten en metadata altijd bij elkaar blijven, wat essentieel is voor het "Plugin First" principe.

### **Basis Structuur (90% van plugins)**

```
plugins/[plugin_naam]/
├── manifest.yaml           # De ID-kaart (wie ben ik?)
├── worker.py               # De Logica (wat doe ik?)
├── schema.py               # Het Contract (wat heb ik nodig?)
├── context_schema.py       # Het visuele contract (wat kan ik laten zien?)
└── test/test_worker.py     # De Kwaliteitscontrole (werk ik correct?)
```

### **Uitgebreide Structuur (event-aware plugins)**

Voor plugins die gebruik maken van event communication ([`BaseEventAwareWorker`](backend/core/base_worker.py:BaseEventAwareWorker)):

```
plugins/[plugin_naam]/
├── manifest.yaml           # De ID-kaart (wie ben ik?)
├── worker.py               # De Logica (wat doe ik?)
├── schema.py               # Het Contract (wat heb ik nodig?)
├── context_schema.py       # Het visuele contract (wat kan ik laten zien?)
├── dtos/                   # Event DTO's (ALLEEN voor event-aware plugins)
│   ├── __init__.py
│   ├── opportunity_signal.py    # Voorbeeld: custom Signal DTO
│   └── threat_alert.py          # Voorbeeld: custom CriticalEvent DTO
└── test/test_worker.py     # De Kwaliteitscontrole (werk ik correct?)
```

### **Bestandsbeschrijvingen**

* **[`manifest.yaml`](plugins/)**: De "ID-kaart" van de plugin. Dit bestand maakt de plugin vindbaar en begrijpelijk voor het Assembly Team. Bevat ook de optionele `event_config` sectie voor event-aware plugins.

* **[`worker.py`](plugins/)**: Bevat de Python-klasse met de daadwerkelijke businesslogica van de plugin. Erft van [`BaseWorker`](backend/core/base_worker.py) of een van de gespecialiseerde basisklassen.

* **[`schema.py`](plugins/)**: Bevat het Pydantic-model dat de structuur en validatieregels voor de configuratieparameters (`params`) van de plugin definieert.

* **[`context_schema.py`](plugins/)**: Bevat het concrete context model voor de visualisatie van gegevens die de plugin produceert. Dit is cruciaal voor de "Trade Explorer" in de frontend.

* **`dtos/`** (optioneel): Bevat custom Data Transfer Objects voor event payloads. **Alleen nodig voor event-aware plugins** die custom event payloads publiceren (niet de standaard [`Signal`](backend/dtos/pipeline/signal.py) of [`CriticalEvent`](backend/dtos/pipeline/) types).
  * *Voorbeeld*: Een [`OpportunityWorker`](backend/core/base_worker.py) die een custom opportunity score publiceert
  * *Voorbeeld*: Een [`ThreatWorker`](backend/core/base_worker.py) die een custom threat alert stuurt

* **[`test/test_worker.py`](plugins/)**: Bevat de verplichte unit tests voor het valideren van de werking van de plugin. Een 100% score als uitkomst van pytest is noodzakelijk voor de succesvolle "enrollment" van een nieuwe plugin.

### **Wanneer dtos/ Map Nodig Is**

De `dtos/` map is **ALLEEN** nodig wanneer:
1. De plugin event-aware is ([`BaseEventAwareWorker`](backend/core/base_worker.py:BaseEventAwareWorker))
2. **EN** de plugin custom event payloads publiceert die niet de standaard types zijn

**95% van plugins heeft GEEN dtos/ map nodig** omdat:
- Ze zijn stateless (geen events)
- Of ze gebruiken standaard DTO's zoals [`Signal`](backend/dtos/pipeline/signal.py) en [`TradePlan`](backend/dtos/pipeline/trade_plan.py)

## **4.2. Formaat Keuzes: YAML vs. JSON**

De keuze voor een dataformaat hangt af van de primaire gebruiker: **een mens of een machine**. We hanteren daarom een hybride model om zowel leesbaarheid als betrouwbaarheid te maximaliseren.

* **YAML voor Menselijke Configuratie**  
  * **Toepassing:** manifest.yaml en alle door de gebruiker geschreven strategy\_blueprint.yaml en operation.yaml-bestanden.  
  * **Waarom:** De superieure leesbaarheid, de mogelijkheid om commentaar toe te voegen, en de flexibelere syntax zijn essentieel voor ontwikkelaars en strategen die deze bestanden handmatig schrijven en onderhouden.  
* **JSON voor Machine-Data**  
  * **Toepassing:** Alle machine-gegenereerde data, zoals API-responses, state-bestanden, en gestructureerde logs.  
  * **Waarom:** De strikte syntax en universele portabiliteit maken JSON de betrouwbare standaard voor communicatie tussen systemen en voor het opslaan van gestructureerde data waar absolute betrouwbaarheid vereist is.

## **4.3. Het Manifest: De Zelfbeschrijvende ID-kaart**

Het manifest.yaml is de kern van het "plugin discovery" mechanisme. Het stelt het Assembly Team in staat om een plugin volledig te begrijpen **zonder de Python-code te hoeven inspecteren**. Dit manifest is een strikt contract dat alle cruciale metadata van een plugin vastlegt.

### **4.3.1. Identification**

De identification-sectie bevat alle beschrijvende metadata.

* **name**: De unieke, machine-leesbare naam (bv. [`market_structure_detector`](plugins/structural_context/market_structure_detector/)).
* **display_name**: De naam zoals deze in de UI wordt getoond.
* **type**: De **cruciale** categorie die bepaalt tot welke van de vijf functionele pijlers de plugin behoort. Toegestane waarden zijn:
  * [`context_worker`](backend/core/enums.py:WorkerType) - "De Cartograaf" - Verrijkt marktdata met context
  * [`opportunity_worker`](backend/core/enums.py:WorkerType) - "De Verkenner" - Herkent handelskansen (NIEUW in V3)
  * [`threat_worker`](backend/core/enums.py:WorkerType) - "De Waakhond" - Detecteert risico's (hernoemd van monitor_worker)
  * [`planning_worker`](backend/core/enums.py:WorkerType) - "De Strateeg" - Transformeert kansen naar plannen (NIEUW in V3)
  * [`execution_worker`](backend/core/enums.py:WorkerType) - "De Uitvoerder" - Voert plannen uit en beheert posities

  **Deprecation Notes:**
  - ⚠️ `analysis_worker` is **DEPRECATED** - gebruik [`opportunity_worker`](backend/core/enums.py:WorkerType) voor signal detection of [`planning_worker`](backend/core/enums.py:WorkerType) voor trade planning
  - ⚠️ `monitor_worker` is **DEPRECATED** - gebruik [`threat_worker`](backend/core/enums.py:WorkerType)
  
* **subtype**: De **sub-categorie** binnen het worker type (NIEUW in V3). Zie sectie 4.3.1b voor alle 27 sub-categorieën.
* **version**: De semantische versie van de plugin (bv. 1.0.1).
* **description**: Een korte, duidelijke beschrijving van de functionaliteit.
* **author**: De naam van de ontwikkelaar.

**Rationale voor de Split:**
De oorspronkelijke [`AnalysisWorker`](backend/core/base_worker.py) categorie combineerde twee fundamenteel verschillende verantwoordelijkheden:
- **Pure analyse** (patroonherkenning, signaal generatie) → Nu [`OpportunityWorker`](backend/core/base_worker.py)
- **Trade constructie** (entry/exit planning, sizing, routing) → Nu [`PlanningWorker`](backend/core/base_worker.py)

Deze scheiding zorgt voor conceptuele zuiverheid en sluit beter aan bij hoe een quant denkt over strategievorming.

### **4.3.1b. De 27 Sub-Categorieën**

V3 introduceert een verfijnde taxonomie met **27 sub-categorieën** verdeeld over de 5 worker types. Deze sub-categorieën bieden fijnmazige classificatie voor betere organisatie, filtering en begrip van plugin functionaliteit.

#### **ContextType (7 sub-categorieën)**

Voor [`ContextWorker`](backend/core/base_worker.py) plugins die marktdata verrijken:

* [`REGIME_CLASSIFICATION`](backend/core/enums.py:ContextType) - Markt regime & conditie classificatie
  * *Voorbeelden:* ADX trend filter, volatility regime classifier
* [`STRUCTURAL_ANALYSIS`](backend/core/enums.py:ContextType) - Technische structuur analyse
  * *Voorbeelden:* Market structure detector, swing point identifier, liquidity zones
* [`INDICATOR_CALCULATION`](backend/core/enums.py:ContextType) - Indicatoren & berekeningen
  * *Voorbeelden:* EMA, RSI, MACD, Bollinger Bands, ATR
* [`MICROSTRUCTURE_ANALYSIS`](backend/core/enums.py:ContextType) - Orderbook & microstructuur
  * *Voorbeelden:* Orderbook imbalance, bid-ask spread analyzer
* [`TEMPORAL_CONTEXT`](backend/core/enums.py:ContextType) - Temporele context
  * *Voorbeelden:* Session analyzer, time-of-day patterns, killzones
* [`SENTIMENT_ENRICHMENT`](backend/core/enums.py:ContextType) - Sentiment & alternatieve data
  * *Voorbeelden:* News sentiment, social media analysis, fear & greed index
* [`FUNDAMENTAL_ENRICHMENT`](backend/core/enums.py:ContextType) - On-chain & fundamentele data
  * *Voorbeelden:* On-chain metrics, earnings data, economic indicators

**Organisatieprincipe:** Type data-verrijking en abstractieniveau

#### **OpportunityType (7 sub-categorieën)**

Voor [`OpportunityWorker`](backend/core/base_worker.py) plugins die handelskansen herkennen:

* [`TECHNICAL_PATTERN`](backend/core/enums.py:OpportunityType) - Technische patroon herkenning
  * *Voorbeelden:* FVG detector, breakout scanner, divergence finder
* [`MOMENTUM_SIGNAL`](backend/core/enums.py:OpportunityType) - Momentum & trend following
  * *Voorbeelden:* Trend continuation, momentum breakout
* [`MEAN_REVERSION`](backend/core/enums.py:OpportunityType) - Mean reversion strategieën
  * *Voorbeelden:* Oversold/overbought, range bounce
* [`STATISTICAL_ARBITRAGE`](backend/core/enums.py:OpportunityType) - Arbitrage & statistical
  * *Voorbeelden:* Pair trading, correlation breaks
* [`EVENT_DRIVEN`](backend/core/enums.py:OpportunityType) - Event-driven signalen
  * *Voorbeelden:* News-based signals, "buy the rumour"
* [`SENTIMENT_SIGNAL`](backend/core/enums.py:OpportunityType) - Sentiment-driven signalen
  * *Voorbeelden:* Extreme fear/greed, social sentiment spikes
* [`ML_PREDICTION`](backend/core/enums.py:OpportunityType) - Machine learning predictions
  * *Voorbeelden:* Trained model predictions, pattern recognition AI

**Organisatieprincipe:** Strategische benadering en theoretische basis

#### **ThreatType (5 sub-categorieën)**

Voor [`ThreatWorker`](backend/core/base_worker.py) plugins die risico's detecteren:

* [`PORTFOLIO_RISK`](backend/core/enums.py:ThreatType) - Portfolio & financieel risico
  * *Voorbeelden:* Max drawdown monitor, exposure monitor, correlation risk
* [`MARKET_RISK`](backend/core/enums.py:ThreatType) - Markt risico & volatiliteit
  * *Voorbeelden:* Volatility spike detector, liquidity drought detector
* [`SYSTEM_HEALTH`](backend/core/enums.py:ThreatType) - Systeem & technische gezondheid
  * *Voorbeelden:* Connection monitor, data gap detector, latency monitor
* [`STRATEGY_PERFORMANCE`](backend/core/enums.py:ThreatType) - Strategie performance
  * *Voorbeelden:* Win rate degradation, parameter drift detector
* [`EXTERNAL_EVENT`](backend/core/enums.py:ThreatType) - Externe events
  * *Voorbeelden:* Breaking news monitor, regulatory change detector

**Organisatieprincipe:** Domein van risico

#### **PlanningPhase (4 sub-categorieën)**

Voor [`PlanningWorker`](backend/core/base_worker.py) plugins die plannen construeren:

* [`ENTRY_PLANNING`](backend/core/enums.py:PlanningPhase) - Entry planning
  * *Voorbeelden:* Limit entry planner, market entry planner, TWAP entry
* [`EXIT_PLANNING`](backend/core/enums.py:PlanningPhase) - Exit planning (stops & targets)
  * *Voorbeelden:* Liquidity target exit, ATR-based stops, fixed R:R
* [`SIZE_PLANNING`](backend/core/enums.py:PlanningPhase) - Position sizing
  * *Voorbeelden:* Fixed risk sizer, Kelly criterion, volatility-based sizing
* [`ORDER_ROUTING`](backend/core/enums.py:PlanningPhase) - Order routing & execution tactics
  * *Voorbeelden:* Default router, iceberg orders, smart order routing

**Organisatieprincipe:** Natuurlijke volgorde van trade planning

#### **ExecutionType (4 sub-categorieën)**

Voor [`ExecutionWorker`](backend/core/base_worker.py) plugins die uitvoeren en beheren:

* [`TRADE_INITIATION`](backend/core/enums.py:ExecutionType) - Trade initiatie
  * *Voorbeelden:* Plan executor, manual trade executor
* [`POSITION_MANAGEMENT`](backend/core/enums.py:ExecutionType) - Actieve position management
  * *Voorbeelden:* Trailing stop manager, partial profit taker, scale-in/out
* [`RISK_SAFETY`](backend/core/enums.py:ExecutionType) - Risk & safety management
  * *Voorbeelden:* Emergency exit agent, circuit breaker, forced liquidation
* [`OPERATIONAL`](backend/core/enums.py:ExecutionType) - Operationele & geplande taken
  * *Voorbeelden:* DCA rebalancer, scheduled rebalancing, portfolio cleanup

**Organisatieprincipe:** Aard van de actie en lifecycle fase

#### **Overzichtstabel**

| Worker Type | Sub-Categorie Enum | Aantal | Organisatie Principe |
|-------------|-------------------|--------|---------------------|
| [`ContextWorker`](backend/core/base_worker.py) | [`ContextType`](backend/core/enums.py:ContextType) | 7 | Type data-verrijking |
| [`OpportunityWorker`](backend/core/base_worker.py) | [`OpportunityType`](backend/core/enums.py:OpportunityType) | 7 | Strategische benadering |
| [`ThreatWorker`](backend/core/base_worker.py) | [`ThreatType`](backend/core/enums.py:ThreatType) | 5 | Domein van risico |
| [`PlanningWorker`](backend/core/base_worker.py) | [`PlanningPhase`](backend/core/enums.py:PlanningPhase) | 4 | Planningsfase |
| [`ExecutionWorker`](backend/core/base_worker.py) | [`ExecutionType`](backend/core/enums.py:ExecutionType) | 4 | Type actie |

**Totaal:** 5 hoofdcategorieën, 27 sub-categorieën

### **4.3.2. Dependencies (Het Data Contract)**

De dependencies-sectie is het formele contract dat definieert welke data een plugin nodig heeft om te functioneren en wat het produceert. Dit is de kern van de "context-bewuste" UI en validatie.

* **requires (Verplichte DataFrame Kolommen)**: Een lijst van datakolommen die een ContextWorker als **harde eis** verwacht in de DataFrame (bv. \['high', 'low', 'close'\]). Het Assembly Team controleert of aan deze vereisten wordt voldaan.
* **provides (Geproduceerde DataFrame Kolommen)**: Een lijst van nieuwe datakolommen die een ContextWorker als **output** toevoegt aan de DataFrame (bv. \['is\_swing\_high'\]).
* **requires\_context (Verplichte Rijke Data)**: Een lijst van **niet-DataFrame** data-objecten die de plugin als **harde eis** verwacht in de TradingContext. Als deze data niet beschikbaar is, zal de plugin in de UI **uitgeschakeld** zijn en zal de ComponentBuilder een fout genereren bij de bootstrap.
  * *Voorbeeld*: \['orderbook\_snapshot'\].
* **uses (Optionele Rijke Data)**: Een lijst van **niet-DataFrame** data-objecten die de plugin kan gebruiken voor een **verbeterde analyse**, maar die **niet verplicht** zijn. Als deze data niet beschikbaar is, zal de plugin in een "fallback-modus" werken.
  * *Voorbeeld*: \['tick\_by\_tick\_volume'\].
* **produces\_events (Gepubliceerde Events)**: **Specifiek voor ThreatWorker-plugins** (was MonitorWorker). Dit is een lijst van de unieke event-namen die deze monitor kan publiceren op de EventBus.

### **4.3.3. Event Configuration (Optioneel - NIEUW in V3)**

De event_config-sectie is een **opt-in feature** voor geavanceerde, event-driven workflows. Deze sectie maakt het mogelijk voor plugins om te specificeren wanneer ze moeten worden aangeroepen en welke events ze publiceren. Dit is cruciaal voor complexe strategieën die asynchroon en parallel werken.

> **⚠️ BELANGRIJK PRINCIPE: Plugin Configuratie Verantwoordelijkheid**
>
> **De plugin is VOLLEDIG verantwoordelijk voor zijn eigen configuratie.**
>
> - Event configuratie is **ONDERDEEL van de plugin** ([`manifest.yaml`](plugins/))
> - **GEEN** externe configuratie bestanden nodig
> - Alles wat de plugin nodig heeft staat in zijn eigen package
> - Dit garandeert dat een plugin volledig zelfstandig en portable is

**Wanneer te gebruiken:**
- 95% van plugins heeft dit **NIET** nodig - de standaard impliciete pijplijn werkt uitstekend
- Alleen voor expert workflows met custom timing of parallelle executie
- Voor plugins die op specifieke triggers moeten reageren (tijd, events, condities)

#### **triggers (Wanneer moet deze worker draaien?)**

Een lijst van events waarop deze plugin moet reageren. Dit kan zijn:

* **Predefined Triggers** - Standaard events die het systeem begrijpt:
  * `on_context_ready` - Wanneer context verrijking compleet is
  * `on_signal_generated` - Wanneer een opportunity signaal is gegenereerd
  * `on_ledger_update` - Wanneer het ledger verandert
  * `on_position_opened` - Wanneer een positie wordt geopend
  * `on_position_closed` - Wanneer een positie wordt gesloten
  * `on_schedule:<schedule_name>` - Tijd-gebaseerd (via [`schedule.yaml`](config/schedule.yaml))

* **Custom Events** - Events van andere plugins (zie `publishes` sectie)

**Voorbeeld:**
```yaml
event_config:
  triggers:
    - "on_schedule:weekly_dca"      # Predefined: tijd-gebaseerd
    - "dca_opportunity_scored"       # Custom: van andere plugin
```

#### **publishes (Wat publiceert deze worker?)**

Een lijst van custom events die deze plugin kan publiceren. Voor elk event moet worden gespecificeerd:

* **event_name**: Unieke naam voor het event
* **payload_type**: Het DTO type van de payload (bijv. `Signal`, `CriticalEvent`, `TradePlan`)
* **description** (optioneel): Beschrijving van wanneer dit event wordt gepubliceerd

**Voorbeeld:**
```yaml
event_config:
  publishes:
    - event_name: "dca_opportunity_scored"
      payload_type: "Signal"
      description: "Published when DCA opportunity score is calculated"
    - event_name: "high_risk_detected"
      payload_type: "CriticalEvent"
      description: "Published when risk level exceeds threshold"
```

#### **requires_all (Wacht op alle triggers?)**

Een boolean die aangeeft of de plugin moet wachten tot **alle** triggers zijn ontvangen voordat deze wordt uitgevoerd. Standaard: `false`.

**Voorbeeld - Smart DCA Planner:**
```yaml
event_config:
  triggers:
    - "dca_opportunity_scored"
    - "dca_risk_assessed"
  requires_all: true  # Wacht tot BEIDE events zijn ontvangen
  publishes:
    - event_name: "dca_plan_ready"
      payload_type: "TradePlan"
```

#### **Volledige Event Config Voorbeeld**

```yaml
# manifest.yaml voor een geavanceerde event-aware plugin
identification:
  name: "adaptive_dca_planner"
  type: "planning_worker"
  subtype: "entry_planning"
  version: "1.0.0"

# Event configuratie (opt-in)
event_config:
  # Deze planner reageert op twee events
  triggers:
    - "dca_opportunity_scored"  # Van OpportunityWorker
    - "dca_risk_assessed"       # Van ThreatWorker
  
  # Wacht tot beide events binnen zijn
  requires_all: true
  
  # Publiceert zijn eigen event
  publishes:
    - event_name: "dca_plan_ready"
      payload_type: "TradePlan"
      description: "Published when adaptive DCA plan is ready for execution"

dependencies:
  requires: ['close', 'volume']
```

#### **Event Validatie**

Het systeem valideert automatisch de event chain tijdens blueprint loading:

* ✅ Alle `triggers` moeten een publisher hebben (ofwel systeem ofwel andere plugin)
* ✅ Alle `publishes` moeten een subscriber hebben (waarschuwing als niemand luistert)
* ✅ Geen circular dependencies toegestaan
* ✅ Payload types moeten bestaan en correct zijn

**Zie ook:**
- [`WORKER_TAXONOMIE_V3.md`](docs/development/251014%20Bijwerken%20documentatie/WORKER_TAXONOMIE_V3.md) - Volledige event architectuur uitleg
- [`Uitwerking Kernafwijking #4A2`](docs/development/251014%20Bijwerken%20documentatie/Uitwerking%20Kernafwijking%20%234A2%20-%20Plugin%20Event%20Architectuur.md) - Deep dive event systeem

### **4.3.4. Permissions (Optioneel)**

De permissions-sectie fungeert als een beveiligingscontract. Standaard heeft een plugin geen toegang tot externe bronnen.

* **network\_access**: Een 'allowlist' van netwerkbestemmingen.  
* **filesystem\_access**: Een 'allowlist' van bestanden of mappen.

## **4.4. De Worker & het BaseWorker Raamwerk**

De [`worker.py`](plugins/) bevat de daadwerkelijke logica. Om de ontwikkeling te versnellen en te standaardiseren, biedt de architectuur een **gelaagde hiërarchie** van basisklassen in de backend. Deze hiërarchie volgt het principe van "opt-in complexiteit" - een plugin erft alleen de functionaliteit die het daadwerkelijk nodig heeft.

### **Basis: Pure Logica**

De standaard [`BaseWorker`](backend/core/base_worker.py) is een simpele, stateless worker perfect voor de meeste use cases:

```python
# plugins/opportunity_workers/fvg_detector/worker.py
from backend.core.base_worker import BaseWorker
from backend.dtos.pipeline.signal import Signal

class FVGDetector(BaseWorker):
    """Detecteert Fair Value Gaps - pure, stateless logica."""
    
    def process(self, context: TradingContext) -> List[Signal]:
        signals = []
        
        # Pure business logica - geen state, geen events
        for i in range(len(context.enriched_df) - 3):
            if self._is_fvg(context.enriched_df, i):
                signals.append(Signal(
                    correlation_id=uuid4(),
                    timestamp=context.enriched_df.index[i],
                    asset=context.asset_pair,
                    direction='long',
                    signal_type='fvg_entry'
                ))
        
        return signals
    
    def _is_fvg(self, df, i):
        # Pure business logica
        return (df['low'].iloc[i+2] > df['high'].iloc[i])
```

**Gebruik dit voor:** 90% van alle plugins - simpel, testbaar, geen side effects.

### **Opt-in Capabilities**

Zie sectie 4.5 voor de volledige uitwerking van gelaagde capaciteiten (state, events, journaling).

## **4.5. Gelaagde Plugin Capaciteiten (NIEUW in V3)**

V3 introduceert een modulair systeem van gespecialiseerde basisklassen gebaseerd op het principe van **"opt-in complexiteit"**. Een plugin erft alleen de capabilities die het daadwerkelijk nodig heeft, wat leidt tot schonere, veiligere en beter testbare code.

### **4.5.1. Filosofie: De "Glijdende Schaal"**

De kernfilosofie is dat een simpele, stateless [`ContextWorker`](backend/core/base_worker.py) geen toegang nodig heeft tot state-persistentie of de event bus. Door deze capaciteiten op te sluiten in specifieke basisklassen, dwingt de architectuur de ontwikkelaar om een bewuste keuze te maken en wordt de standaard plugin zo simpel en veilig mogelijk gehouden.

We definiëren drie fundamentele "cross-cutting" capaciteiten:

1. **State Persistence** - Het vermogen om een intern "geheugen" te hebben
2. **Event Communication** - Het vermogen om met andere plugins te "praten" en te "luisteren"
3. **Historical Journaling** - Het vermogen om bij te dragen aan het officiële "verhaal" van de strategie

### **4.5.2. De Ladder van Complexiteit**

```
BaseWorker (90% van plugins)
    ├─ Pure, stateless functie
    └─ Geen dependencies
    
BaseStatefulWorker (5%)
    ├─ Automatisch state persistence
    └─ Crash recovery via journaling
    
BaseEventAwareWorker (5%)
    ├─ Event ontvangst via on_event()
    └─ Event publicatie via self.emit()
    
BaseJournalingWorker (Zeldzaam)
    └─ Contributeert aan StrategyJournal

Combinaties (Zeer zeldzaam)
    └─ Via multiple inheritance
```

### **4.5.3. Capaciteit 1: State Persistence**

**Doel:** Plugins in staat stellen om hun interne staat op een atomische en crash-bestendige manier te beheren.

**Voorbeeld - Trailing Stop Manager:**
```python
# plugins/execution_workers/trailing_stop_manager/worker.py
from backend.core.base_worker import BaseStatefulWorker

class TrailingStopManager(BaseStatefulWorker):
    """Beheert trailing stops met state persistence."""
    
    def process(self, context: TradingContext) -> None:
        current_price = context.current_price
        
        # Lees state (automatisch geladen bij initialisatie)
        high_water_mark = self.state.get('high_water_mark', current_price)
        
        # Update state
        if current_price > high_water_mark:
            self.state['high_water_mark'] = current_price
            self.commit_state()  # Atomic write (journal → fsync → rename)
        
        # Business logica
        new_stop = high_water_mark * (1 - self.params.trail_percent)
        self._update_stop_loss(new_stop)
```

**Architectuur:**
- **Interface:** [`BaseStatefulWorker`](backend/core/base_worker.py:BaseStatefulWorker) biedt `self.state` en `self.commit_state()`
- **Motor:** [`StatePersistenceAdapter`](backend/assembly/) (geïnjecteerd door ComponentBuilder)
- **Crash Recovery:** Automatisch via `.journal` → `fsync` → `rename` patroon

### **4.5.4. Capaciteit 2: Event Communication**

**Doel:** "Expert" plugins in staat stellen om onderling te communiceren via events, zonder de EventBus direct aan te hoeven spreken.

#### **Verantwoordelijkheidsverdeling: Plugin vs. Adapter**

De event architectuur maakt een **strikte scheiding** tussen business logica (plugin) en event orchestratie (adapter):

| Aspect | Plugin Verantwoordelijkheid | Adapter Verantwoordelijkheid |
|--------|---------------------------|----------------------------|
| **Business Logica** | ✅ Implementeert `on_event()` handlers | ❌ Weet niets van business logica |
| **Event Publicatie** | ✅ Roept `self.emit()` aan | ❌ Weet niet wat events betekenen |
| **Event State** | ❌ Geen event state tracking | ✅ Tracked welke events ontvangen zijn |
| **Event Routing** | ❌ Weet niet wie luistert | ✅ Routeert naar juiste subscribers |
| **Event Validatie** | ❌ Valideert niet event chain | ✅ Valideert payload types & dependencies |
| **Event Timing** | ❌ Weet niet wanneer events komen | ✅ Beheert `requires_all` logica |
| **Configuration** | ✅ Definieert in `manifest.yaml` | ✅ Leest `manifest.yaml` |

**Kernprincipe:** De plugin implementeert **ALLEEN** zijn business methods ([`on_event()`](backend/core/base_worker.py) handlers). De [`PluginEventAdapter`](backend/assembly/) bevat **ALLE** event logica (routing, validatie, timing, state).

#### **Twee-Niveaus Event Routing**

De event architectuur gebruikt een **twee-niveaus routing systeem**:

**Niveau 1: Plugin Scope (Event Contract)**
- Gedefinieerd in [`manifest.yaml`](plugins/) van de plugin
- Bepaalt: "Wat zijn mijn triggers? Wat publiceer ik?"
- Dit is het **interface contract** van de plugin
- **Verantwoordelijkheid:** Plugin auteur

```yaml
# manifest.yaml (Plugin scope - het contract)
event_config:
  triggers:
    - "dca_opportunity_scored"
    - "dca_risk_assessed"
  requires_all: true
  publishes:
    - event_name: "dca_plan_ready"
      payload_type: "TradePlan"
```

**Niveau 2: Applicatie Scope (Orchestratie)**
- Gedefinieerd in [`event_map.yaml`](config/) en [`wiring_map.yaml`](config/)
- Bepaalt: "Welke plugins praten met elkaar? In welke volgorde?"
- Dit is de **workflow configuratie** van de strategie
- **Verantwoordelijkheid:** Strategy Operator / OperationBuilder

```yaml
# event_map.yaml (Applicatie scope - de orchestratie)
event_flows:
  - publisher: "dca_opportunity_scorer"
    event: "dca_opportunity_scored"
    subscribers:
      - "adaptive_dca_planner"
  
  - publisher: "dca_risk_assessor"
    event: "dca_risk_assessed"
    subscribers:
      - "adaptive_dca_planner"
```

**Waarom deze scheiding?**
- ✅ Plugin blijft portable - werkt in elke configuratie
- ✅ Strategy creator bepaalt workflow - zonder plugin code te wijzigen
- ✅ Clear separation of concerns - plugin = logica, config = orchestratie

#### **Code Voorbeelden**

**Voorbeeld - Event Publisher:**
```python
# plugins/opportunity_workers/dca_opportunity_scorer/worker.py
from backend.core.base_worker import BaseEventAwareWorker

class DCAOpportunityScorer(BaseEventAwareWorker):
    """Event-aware worker die opportunity scores publiceert."""
    
    def process(self, context: TradingContext) -> List[Signal]:
        score = self._calculate_score(context)
        
        signal = Signal(
            correlation_id=uuid4(),
            timestamp=context.current_timestamp,
            asset=context.asset_pair,
            direction='long',
            signal_type='dca_opportunity',
            metadata={'opportunity_score': score}
        )
        
        # Publiceer event (simpele API - adapter handled routing)
        self.emit("dca_opportunity_scored", signal)
        
        return [signal]
```

**Voorbeeld - Event Subscriber:**
```python
# plugins/planning_workers/adaptive_dca_planner/worker.py
from backend.core.base_worker import BaseEventAwareWorker

class AdaptiveDCAPlanner(BaseEventAwareWorker):
    """Event-aware planner die reageert op opportunity en risk events."""
    
    def __init__(self, params):
        super().__init__(params)
        # Pure state - GEEN event state logica hier
        self._opportunity_score: Optional[float] = None
        self._risk_level: Optional[str] = None
    
    def on_event(self, event_name: str, payload: Any) -> None:
        """
        ALLEEN business logica - adapter roept dit aan.
        Plugin weet NIET welke events wanneer komen - dat regelt de adapter.
        """
        if event_name == "dca_opportunity_scored":
            self._opportunity_score = payload.metadata['opportunity_score']
        elif event_name == "dca_risk_assessed":
            self._risk_level = payload.metadata['risk_level']
    
    def process(self, signal: Signal, context: TradingContext) -> Optional[TradePlan]:
        """
        Pure business logica.
        Adapter zorgt ervoor dat dit ALLEEN wordt aangeroepen als alle events binnen zijn
        (via requires_all in manifest.yaml).
        """
        if self._opportunity_score is None or self._risk_level is None:
            return None  # Nog niet klaar (zou niet moeten gebeuren als adapter correct werkt)
        
        amount = self._calculate_amount(
            self._opportunity_score,
            self._risk_level
        )
        
        if amount == 0:
            return None
        
        plan = TradePlan(...)
        
        # Publiceer resultaat - adapter handled routing
        self.emit("dca_plan_ready", plan)
        
        return plan
```

#### **Wat de Plugin NIET doet**

❌ **Geen event state tracking:**
```python
# FOUT - Dit hoort in de adapter, niet in de plugin
if self._received_events.count() >= 2:
    self.process()
```

❌ **Geen event routing logica:**
```python
# FOUT - Dit hoort in de adapter, niet in de plugin
if event_name == "x":
    self._forward_to_other_plugin(payload)
```

❌ **Geen event timing logica:**
```python
# FOUT - Dit hoort in de adapter, niet in de plugin
if self._last_event_time < now() - timedelta(seconds=5):
    self._timeout_handler()
```

**Al deze logica zit in [`PluginEventAdapter`](backend/assembly/)** - de plugin blijft puur business logica.

#### **Architectuur Samenvatting**

- **Interface:** [`BaseEventAwareWorker`](backend/core/base_worker.py:BaseEventAwareWorker) biedt `self.emit()` en `on_event()`
- **Motor:** [`PluginEventAdapter`](backend/assembly/) (geïnjecteerd door ComponentBuilder)
- **Configuratie Niveau 1:** `event_config` in [`manifest.yaml`](plugins/) (plugin contract)
- **Configuratie Niveau 2:** [`event_map.yaml`](config/) + [`wiring_map.yaml`](config/) (workflow orchestratie)

### **4.5.5. Capaciteit 3: Historical Journaling**

**Doel:** Plugins in staat stellen om bij te dragen aan het [`StrategyJournal`](backend/core/strategy_journal.py), zodat elke beslissing en observatie traceerbaar is.

**Voorbeeld:**
```python
# plugins/planning_workers/decision_logger/worker.py
from backend.core.base_worker import BaseJournalingWorker

class DecisionLogger(BaseJournalingWorker):
    """Logt beslissingen naar het StrategyJournal."""
    
    def process(self, opportunity, threats, context):
        entries = []
        
        if threats:
            # Log afgewezen kans
            entries.append({
                "event_type": "OPPORTUNITY_REJECTED",
                "opportunity_id": opportunity.opportunity_id,
                "rejection_reason": {
                    "threat_id": threats[0].threat_id,
                    "threat_type": threats[0].threat_type
                }
            })
        else:
            # Log geaccepteerde kans
            entries.append({
                "event_type": "OPPORTUNITY_ACCEPTED",
                "opportunity_id": opportunity.opportunity_id
            })
        
        # Log entries (automatisch timestamp + metadata toegevoegd)
        self.log_entries(entries, context)
```

**Architectuur:**
- **Interface:** [`BaseJournalingWorker`](backend/core/base_worker.py:BaseJournalingWorker) biedt `self.log_entries()`
- **Motor:** [`JournalPersistenceAdapter`](backend/assembly/) (geïnjecteerd door ComponentBuilder)
- **Output:** Append-only JSON log in [`StrategyJournal`](backend/core/strategy_journal.py)

### **4.5.6. Combinaties via Multiple Inheritance**

Voor de zeldzame gevallen waar meerdere capabilities nodig zijn:

```python
class ComplexWorker(BaseStatefulWorker, BaseEventAwareWorker):
    """Worker met ZOWEL state ALS events."""
    
    def on_event(self, event_name: str, payload: Any):
        # Update state op basis van event
        self.state['last_event'] = event_name
        self.state['event_count'] = self.state.get('event_count', 0) + 1
        self.commit_state()
    
    def process(self, context: TradingContext):
        # Gebruik state
        event_count = self.state.get('event_count', 0)
        
        # Business logica
        result = self._calculate(event_count)
        
        # Publiceer event
        self.emit("result_ready", result)
        
        return result
```

### **4.5.7. Testing Voordelen**

De gelaagde architectuur maakt testing eenvoudiger:

```python
# tests/test_fvg_detector.py
def test_fvg_detector():
    # Simpel: geen mocks nodig voor state of events
    detector = FVGDetector(params)
    context = create_test_context()
    
    signals = detector.process(context)
    
    # Verifieer pure business logica
    assert len(signals) == 2
    assert signals[0].signal_type == 'fvg_entry'

# tests/test_adaptive_dca_planner.py
def test_adaptive_dca_planner():
    planner = AdaptiveDCAPlanner(params)
    
    # Optioneel: mock event handler
    mock_handler = MockEventHandler()
    planner.set_event_handler(mock_handler)
    
    # Simuleer events
    planner.on_event("dca_opportunity_scored", Signal(...))
    planner.on_event("dca_risk_assessed", CriticalEvent(...))
    
    # Test business logica
    plan = planner.process(signal, context)
    
    assert plan.amount == 1500  # Expected amount based on scores
    assert mock_handler.emitted_events[0][0] == "dca_plan_ready"
```

**Zie ook:**
- [`Uitwerking Kernafwijking #4`](docs/development/251014%20Bijwerken%20documentatie/Uitwerking%20Kernafwijking%20%234%20-%20Gelaagde%20Plugin%20Capaciteiten.md) - Volledige uitwerking gelaagde capaciteiten
- [`Uitwerking Kernafwijking #4A2`](docs/development/251014%20Bijwerken%20documentatie/Uitwerking%20Kernafwijking%20%234A2%20-%20Plugin%20Event%20Architectuur.md) - Deep dive event architectuur