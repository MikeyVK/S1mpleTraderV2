# **1. S1mpleTrader V2: De Communicatie Architectuur**

Versie: 3.0  
Status: Definitief  
Laatst bijgewerkt: 2025-10-14

---

## **Inhoudsopgave**

1. [Visie & Filosofie: Scheiding van Logica](#11-visie--filosofie-scheiding-van-logica)
2. [De Architectuur: Het EventAdapter Patroon](#12-de-architectuur-het-eventadapter-patroon)
3. [NIEUW: PluginEventAdapter Architectuur](#13-nieuw-plugineventadapter-architectuur)
4. [NIEUW: Event Chain Validatie](#14-nieuw-event-chain-validatie)
5. [De Levenscyclus in de Praktijk](#15-de-levenscyclus-in-de-praktijk)
6. [De Event Map: De Grondwet van de Communicatie](#16-de-event-map-de-grondwet-van-de-communicatie)
7. [Event-Driven Architectuur: Drie Niveaus](#17-event-driven-architectuur-drie-niveaus)
8. [De Operator Suite (V3)](#18-de-operator-suite-v3)

---

## **1.1. Visie & Filosofie: Scheiding van Logica**

### **1.1.1. Inleiding & Doel**

Dit document beschrijft de communicatie-architectuur van S1mpleTrader V2. De kern van dit ontwerp is niet simpelweg het gebruik van een event-gedreven model, maar de **radicale scheiding tussen businesslogica en communicatielogica**.

Het doel is een systeem te creëren waarin de componenten die de daadwerkelijke strategie- en businesslogica bevatten (Operators en Workers) volledig puur, agnostisch en onwetend zijn van het communicatiemechanisme (de EventBus).

### **1.1.2. De Filosofie: Bus-Agnostische Componenten**

In deze architectuur is een Operator (bv. de [`OpportunityOperator`](backend/core/operators/base_operator.py)) een pure Python-klasse. Zijn taak is het uitvoeren van een specifieke business-taak: hij accepteert een DTO (Data Transfer Object) als input en retourneert een DTO als output. Hij weet niets van "subscriben" of "publishen".

De volledige verantwoordelijkheid voor de communicatie met de EventBus wordt gedelegeerd aan een generieke tussenlaag: het **EventAdapter Patroon**.

### **1.1.3. Kernprincipe: Event-Driven is OPTIONEEL**

Een fundamenteel principe in V3 is dat **event-driven communicatie optioneel is**. Het systeem ondersteunt drie abstractieniveaus:

1. **Niveau 1: Impliciete Pijplijnen (95% van gebruik)**  
   De quant definieert workers, het systeem genereert automatisch de event chain. Geen event management nodig.

2. **Niveau 2: Predefined Triggers (Opt-in)**  
   Gebruik voorgedefinieerde trigger namen voor common use cases zonder custom events.

3. **Niveau 3: Custom Event Chains (Expert Mode)**  
   Volledige controle met custom events en complexe workflows.

Dit "progressive complexity" model zorgt ervoor dat beginners direct kunnen starten, terwijl experts alle kracht hebben die ze nodig hebben.

---

## **1.2. De Architectuur: Het EventAdapter Patroon**

### **1.2.1. De EventAdapter als Vertaler**

De EventAdapter is een generieke, herbruikbare "vertaler" wiens enige taak het is om een brug te slaan tussen de EventBus en een pure business-component (Operator). Zijn gedrag wordt niet in code, maar in configuratie gedefinieerd via de [`wiring_map.yaml`](config/wiring_map.yaml).

**Voorbeeld van een wiring_map.yaml-regel:**

```yaml
# wiring_map.yaml (Applicatie-niveau routing)
- adapter_id: "OpportunityPipelineAdapter"
  listens_to: "ContextReady"
  invokes:
    component: "OpportunityOperator"
    method: "run_pipeline"
  publishes_result_as: "SignalsGenerated"
```

Deze regel instrueert het systeem om:

1. Een EventAdapter te creëren.
2. Deze adapter te laten luisteren naar het `ContextReady`-event.
3. Wanneer dat event binnenkomt, de [`run_pipeline()`](backend/core/operators/base_operator.py:run_pipeline)-methode van de OpportunityOperator aan te roepen met de event-payload.
4. Als de methode een resultaat teruggeeft, dit resultaat te publiceren op de bus onder de naam `SignalsGenerated`.

### **1.2.2. De Rol van de EventWiringFactory**

Tijdens het opstarten van de applicatie leest de [`EventWiringFactory`](backend/assembly/event_wiring_factory.py) de volledige [`wiring_map.yaml`](config/wiring_map.yaml). Voor elke regel in de map creëert en configureert het een EventAdapter-instantie en abonneert deze op de EventBus.

---

## **1.3. NIEUW: PluginEventAdapter Architectuur**

### **1.3.1. Filosofie: Gecontroleerde Autonomie**

**SHIFT 4: Van Hard-Coded Bus Koppeling naar Bus-Agnostische Plugin Isolatie**

In V3 introduceert S1mpleTrader een krachtig maar elegant patroon om plugins **volledig te isoleren** van de EventBus-implementatie, terwijl ze toch kunnen deelnemen aan event-gedreven communicatie.

De kernfilosofie is **gecontroleerde autonomie**: een plugin moet kunnen reageren op en bijdragen aan het grotere "gesprek" binnen een strategie, maar op een manier die:

1. **Expliciet en Zelf-Documenterend is:** De communicatiebehoeften van een plugin zijn vastgelegd in zijn [`manifest.yaml`](plugins/*/manifest.yaml).
2. **Volledig Bus-Agnostisch is:** De plugin-code zelf heeft geen enkele kennis van de onderliggende EventBus-technologie.
3. **Veilig en Robuust is:** Het systeem valideert de events en hun datastructuren (DTO's) om runtime-fouten te voorkomen.

### **1.3.2. De Drie Lagen van Plugin Event Architectuur**

#### **Laag 1: De Configuratie (manifest.yaml) - Het "Communicatiepaspoort"**

Dit is waar de plugin zijn communicatieve "vingerafdruk" definieert:

```yaml
# plugins/smart_dca_worker/manifest.yaml
identification:
  name: "smart_dca_worker"
  type: "ExecutionWorker"
  subtype: "operational"
  version: "1.0.0"

# Deze sectie definieert de 'taal' die deze plugin spreekt.
# Het fungeert als een lokale, plugin-specifieke event_map.
publishes:
  - event_name: "DCA_PURCHASE_EXECUTED"
    payload_dto: "DcaPurchaseConfirmation"

# Deze sectie definieert de 'reflexen' van de plugin.
# Het fungeert als een lokale, plugin-specifieke wiring_map.
listens_to:
  # Luistert naar een Systeem-Event (van de Scheduler)
  - event_name: "DAILY_MARKET_OPEN_TICK"
    invokes: "on_trading_window_opened"
  
  # Luistert naar een Custom Event (van een andere plugin)
  - event_name: "MARKET_IS_DIPPING"
    invokes: "on_market_dip_detected"
```

**Cruciale Scheiding:**
- **manifest.yaml** definieert PLUGIN-niveau event contracts (lokale "taal")
- **wiring_map.yaml** definieert APPLICATIE-niveau event routing (globale "bedrading")

Dit is een fundamentele twee-niveaus event routing architectuur.

#### **Laag 2: De Interface (BaseEventAwareWorker) - Het "Dashboard"**

Dit is de abstracte basisklasse waar een event-bewuste plugin van erft:

```python
# backend/core/base_worker.py
from backend.core.interfaces import IEventHandler

class BaseEventAwareWorker(BaseWorker):
    """
    Worker die events kan ontvangen en publiceren via abstractie.
    
    De worker kent GEEN concrete EventBus, alleen een interface.
    """
    
    def __init__(self, params: Any):
        super().__init__(params)
        self._event_handler: Optional[IEventHandler] = None
    
    def set_event_handler(self, handler: IEventHandler) -> None:
        """Geïnjecteerd door de Operator tijdens setup."""
        self._event_handler = handler
    
    def emit(self, event_name: str, payload: BaseModel) -> None:
        """
        Simpele API voor plugin om events te publiceren.
        
        Example:
            signal = Signal(...)
            self.emit("dca_opportunity_scored", signal)
        """
        if self._event_handler:
            self._event_handler.publish(event_name, payload)
    
    def on_event(self, event_name: str, payload: Any) -> None:
        """
        Override deze methode om events te ontvangen.
        
        Example:
            def on_event(self, event_name, payload):
                if event_name == "dca_opportunity_scored":
                    self._opportunity_score = payload.metadata['score']
        """
        pass  # Default: doe niets
```

**Key Points:**
- Workers gebruiken [`IEventHandler`](backend/core/interfaces/event_handler.py) interface, niet de concrete EventBus
- Dit maakt workers testbaar en herbruikbaar
- De plugin ontwikkelaar hoeft alleen [`emit()`](backend/core/base_worker.py:BaseEventAwareWorker.emit) en [`on_event()`](backend/core/base_worker.py:BaseEventAwareWorker.on_event) te gebruiken

#### **Laag 3: De Motor (PluginEventAdapter) - De "Vertaler"**

Dit is de onzichtbare maar cruciale "motor" die het dashboard van de worker verbindt met de EventBus:

```python
# backend/assembly/plugin_event_adapter.py
from backend.core.interfaces import IWorker, IEventBus, IEventHandler

class PluginEventAdapter(IEventHandler):
    """
    De 'vertaler' die de bus-agnostische worker verbindt met de EventBus.
    
    Verantwoordelijkheden:
    1. Leest bij initialisatie het manifest.yaml van zijn toegewezen worker
    2. Valideert de publishes-definities
    3. Abonneert zich op de EventBus voor alle events in listens_to
    4. Roept worker methodes aan wanneer events binnenkomen
    5. Valideert en publiceert events namens de worker
    """
    
    def __init__(self, 
                 worker_instance: IWorker, 
                 manifest_config: Dict[str, Any], 
                 event_bus: IEventBus):
        self._worker = worker_instance
        self._manifest = manifest_config
        self._bus = event_bus
        
        # Parse toegestane publicaties
        self._allowed_publications: set[str] = {
            p['event_name'] for p in manifest_config.get('publishes', [])
        }
        
        # Abonneer op events
        self._subscribe_to_events()
    
    def _subscribe_to_events(self) -> None:
        """Leest de 'listens_to' sectie en abonneert zich op de EventBus."""
        subscriptions = self._manifest.get('listens_to', [])
        
        for subscription in subscriptions:
            event_name = subscription['event_name']
            method_name = subscription['invokes']
            
            handler = getattr(self._worker, method_name, None)
            
            if handler and callable(handler):
                # Wrapper zorgt voor correcte payload doorgave
                def handler_wrapper(payload: BaseModel) -> None:
                    handler(payload=payload)
                
                self._bus.subscribe(event_name, handler_wrapper)
                logger.info(
                    f"Adapter: Subscribing '{event_name}' to "
                    f"'{self._worker.__class__.__name__}.{method_name}'"
                )
            else:
                logger.warning(
                    f"Method '{method_name}' not found on worker "
                    f"'{self._worker.__class__.__name__}'"
                )
    
    def publish(self, event_name: str, payload: BaseModel) -> None:
        """
        IEventHandler interface implementatie.
        Valideert en publiceert een event namens de worker.
        """
        if event_name not in self._allowed_publications:
            raise PermissionError(
                f"Worker '{self._worker.__class__.__name__}' has no permission "
                f"to publish event '{event_name}'. "
                f"Declare it in the 'publishes' section of the manifest."
            )
        
        self._bus.publish(event_name, payload)
        logger.debug(
            f"Adapter: Publishing '{event_name}' from "
            f"'{self._worker.__class__.__name__}'"
        )
```

### **1.3.3. Twee-Niveaus Event Routing**

**Cruciale Architectonische Beslissing:**

S1mpleTrader V3 implementeert een **twee-niveaus event routing systeem**:

1. **Plugin-Niveau (manifest.yaml):**
   - Definieert welke events een plugin **kan** publiceren/ontvangen
   - Dit is het "event contract" van de plugin
   - Dit is **lokaal** aan de plugin en portable

2. **Applicatie-Niveau (wiring_map.yaml):**
   - Definieert de **daadwerkelijke routing** tussen Operators
   - Dit is de "bedrading" van de applicatie
   - Dit is **globaal** en configureerbaar per strategie

**Voorbeeld:**

```yaml
# Plugin manifest (plugins/dca_scorer/manifest.yaml)
publishes:
  - event_name: "dca_opportunity_scored"
    payload_dto: "Signal"

# Applicatie wiring (config/wiring_map.yaml)
- adapter_id: "OpportunityPipelineAdapter"
  listens_to: "ContextReady"
  invokes:
    component: "OpportunityOperator"
    method: "run_pipeline"
  publishes_result_as: "SignalsGenerated"  # ← Applicatie-niveau naam
```

Dit scheidt **wat een plugin kan doen** van **hoe de applicatie is georganiseerd**.

---

## **1.4. NIEUW: Event Chain Validatie**

### **1.4.1. Het Probleem: Event Chain Integriteit**

In een event-driven systeem kunnen complexe problemen ontstaan:

- **Orphaned Events:** Een plugin publiceert een event, maar niemand luistert ernaar
- **Dead-End Events:** Een plugin verwacht een event, maar niemand publiceert het
- **Circular Dependencies:** Event A triggert B, B triggert C, C triggert A
- **Type Mismatches:** Een plugin publiceert `Signal`, een ander verwacht `TradePlan`

Deze problemen zijn moeilijk te debuggen tijdens runtime. **Oplossing: Validatie bij startup.**

### **1.4.2. Event Chain Validator**

De [`EventChainValidator`](backend/assembly/event_chain_validator.py) analyseert de volledige event chain tijdens startup:

```python
# backend/assembly/event_chain_validator.py
from typing import Dict, List, Set
from backend.config.schemas import StrategyBlueprint

class EventChainValidator:
    """
    Valideert de integriteit van event chains tijdens startup.
    
    Checks:
    1. Alle triggers hebben een publisher
    2. Geen circular dependencies
    3. Dead-end event detectie (waarschuwing)
    4. Payload DTO type consistency
    """
    
    def validate(self, 
                 blueprint: StrategyBlueprint,
                 wiring_map: Dict,
                 operators_config: Dict) -> ValidationResult:
        """
        Voert volledige validatie uit.
        
        Args:
            blueprint: Strategy blueprint met workforce definitie
            wiring_map: Applicatie-niveau event routing
            operators_config: Operator configuratie
            
        Returns:
            ValidationResult met errors en warnings
        """
        result = ValidationResult()
        
        # Build event graph
        graph = self._build_event_graph(blueprint, wiring_map)
        
        # Check 1: Publisher/Subscriber consistency
        self._validate_publishers_and_subscribers(graph, result)
        
        # Check 2: Circular dependencies
        self._detect_circular_dependencies(graph, result)
        
        # Check 3: Dead-end events
        self._detect_dead_ends(graph, result)
        
        # Check 4: DTO type consistency
        self._validate_payload_types(graph, result)
        
        return result
    
    def _build_event_graph(self, 
                          blueprint: StrategyBlueprint,
                          wiring_map: Dict) -> EventGraph:
        """
        Bouwt een gerichte graaf van alle event relaties.
        
        Nodes: Events
        Edges: Publisher → Event → Subscriber
        """
        graph = EventGraph()
        
        # Parse wiring_map (applicatie-niveau)
        for wire in wiring_map:
            event_name = wire['listens_to']
            result_event = wire.get('publishes_result_as')
            
            if result_event:
                graph.add_edge(event_name, result_event)
        
        # Parse plugin manifests (plugin-niveau)
        for worker_config in blueprint.all_workers():
            manifest = self._load_manifest(worker_config['plugin'])
            
            # Publishes
            for pub in manifest.get('publishes', []):
                graph.add_publisher(pub['event_name'], worker_config['plugin'])
            
            # Listens_to
            for sub in manifest.get('listens_to', []):
                graph.add_subscriber(sub['event_name'], worker_config['plugin'])
        
        return graph
    
    def _validate_publishers_and_subscribers(self,
                                            graph: EventGraph,
                                            result: ValidationResult) -> None:
        """
        Check 1: Alle triggers moeten een publisher hebben.
        """
        for event_name in graph.get_subscribed_events():
            publishers = graph.get_publishers(event_name)
            
            if not publishers:
                result.add_error(
                    f"Event '{event_name}' has subscribers but no publishers! "
                    f"Subscribers: {graph.get_subscribers(event_name)}"
                )
    
    def _detect_circular_dependencies(self,
                                     graph: EventGraph,
                                     result: ValidationResult) -> None:
        """
        Check 2: Detecteer circular dependencies via DFS.
        """
        visited = set()
        rec_stack = set()
        
        def dfs(event: str, path: List[str]) -> None:
            visited.add(event)
            rec_stack.add(event)
            
            for next_event in graph.get_downstream_events(event):
                if next_event not in visited:
                    dfs(next_event, path + [next_event])
                elif next_event in rec_stack:
                    # Circular dependency detected!
                    cycle = path[path.index(next_event):] + [next_event]
                    result.add_error(
                        f"Circular dependency detected: {' → '.join(cycle)}"
                    )
            
            rec_stack.remove(event)
        
        for event in graph.get_all_events():
            if event not in visited:
                dfs(event, [event])
    
    def _detect_dead_ends(self,
                         graph: EventGraph,
                         result: ValidationResult) -> None:
        """
        Check 3: Detecteer events die worden gepubliceerd maar niet gebruikt.
        """
        for event_name in graph.get_published_events():
            subscribers = graph.get_subscribers(event_name)
            
            if not subscribers:
                result.add_warning(
                    f"Event '{event_name}' is published but has no subscribers. "
                    f"Is this intentional?"
                )
    
    def _validate_payload_types(self,
                               graph: EventGraph,
                               result: ValidationResult) -> None:
        """
        Check 4: Valideer dat publishers en subscribers compatibele DTO types gebruiken.
        """
        for event_name in graph.get_all_events():
            publishers = graph.get_publishers_with_types(event_name)
            subscribers = graph.get_subscribers_with_types(event_name)
            
            # Check type consistency
            publisher_types = {p['payload_dto'] for p in publishers}
            
            if len(publisher_types) > 1:
                result.add_error(
                    f"Event '{event_name}' has multiple publishers with "
                    f"different payload types: {publisher_types}"
                )
```

### **1.4.3. Validatie tijdens Bootstrap**

De validatie wordt automatisch uitgevoerd tijdens het opstarten:

```python
# backend/assembly/context_builder.py
class ContextBuilder:
    """Orkestreert de volledige bootstrap fase."""
    
    def bootstrap(self, 
                  blueprint: StrategyBlueprint,
                  platform_config: PlatformConfig) -> BootstrapResult:
        """
        Bootstrap fase met event chain validatie.
        """
        # 1. Load alle configuraties
        wiring_map = self._load_wiring_map()
        operators_config = self._load_operators_config()
        
        # 2. Valideer event chain
        validator = EventChainValidator()
        validation_result = validator.validate(
            blueprint, 
            wiring_map, 
            operators_config
        )
        
        # 3. Stop als er errors zijn
        if validation_result.has_errors():
            raise EventChainValidationError(
                "Event chain validation failed:\n" + 
                "\n".join(validation_result.errors)
            )
        
        # 4. Log warnings
        for warning in validation_result.warnings:
            logger.warning(f"Event chain warning: {warning}")
        
        # 5. Continue met bootstrap...
        components = self._build_components(blueprint)
        
        return BootstrapResult(
            components=components,
            validation_result=validation_result
        )
```

### **1.4.4. Voorbeeld Validatie Output**

```
[INFO] Event Chain Validation Started
[INFO] Building event graph from blueprint and wiring_map...
[INFO] Found 12 events, 8 publishers, 15 subscribers
[✓] Check 1: All triggers have publishers
[✓] Check 2: No circular dependencies detected
[!] Check 3: Dead-end event detected: 'debug_signal_logged' has no subscribers
[✓] Check 4: Payload DTO types are consistent
[WARN] Event 'debug_signal_logged' is published but has no subscribers. Is this intentional?
[SUCCESS] Event chain validation completed with 0 errors, 1 warning
```

---

## **1.5. De Levenscyclus in de Praktijk**

### **1.5.1. De Bootstrap Fase (Het "Bedraden" van het Systeem)**

1. De gebruiker start een Operation via een entrypoint.
2. De applicatie laadt de volledige "Configuratie Trein":
   - [`platform.yaml`](config/platform.yaml)
   - [`strategy_blueprint.yaml`](config/runs/strategy_blueprint.yaml)
   - [`operators.yaml`](config/operators.yaml) (NIEUW in V3)
   - [`wiring_map.yaml`](config/wiring_map.yaml)
3. De **[`EventChainValidator`](backend/assembly/event_chain_validator.py)** valideert de event integriteit (NIEUW in V3).
4. De **[`ComponentBuilder`](backend/assembly/context_builder.py)** instantieert alle benodigde componenten:
   - 5 Operators (Context, Opportunity, Threat, Planning, Execution)
   - Alle Workers per Operator
   - PluginEventAdapters voor event-aware workers
5. De **[`ContextBootstrapper`](backend/assembly/context_builder.py)** zorgt voor het vullen van de initiële, rijke context *voordat* de Operation live gaat.
6. De **[`EventWiringFactory`](backend/assembly/event_wiring_factory.py)** leest de [`wiring_map.yaml`](config/wiring_map.yaml) en creëert de EventAdapters, die zich abonneren op de EventBus.
7. Het `OperationStarted`-event wordt gepubliceerd. Het systeem is nu "live".

### **1.5.2. Een Runtime Voorbeeld (De Tick-Loop met 5 Operators)**

**V3 Flow (5 Operators):**

```
1. ExecutionEnvironment publiceert TradingContext
                    ↓
2. ContextOperator verrijkt context
   └→ publiceert ContextReady
                    ↓
        ┌───────────┴───────────┐
        ▼                       ▼
3. OpportunityOperator    ThreatOperator
   (parallelle executie)
   └→ publiceert          └→ publiceert
      SignalsGenerated       ThreatEvents
        │                       │
        └───────────┬───────────┘
                    ▼
4. PlanningOperator (combineert beide)
   └→ publiceert PlansReady
                    ↓
5. ExecutionOperator voert uit
   └→ publiceert ExecutionApproved
```

**Belangrijke Wijziging t.o.v. V2:**
- **ExecutionEnvironment** publiceert nu direct [`TradingContext`](backend/dtos/state/trading_context.py) in plaats van `MarketSnapshot`
- **ContextOperator** is nu een standaard operator (verrijkt bestaande context)
- **OpportunityOperator** en **ThreatOperator** draaien parallel
- **PlanningOperator** combineert opportunities en threats tot plannen

---

## **1.6. De Event Map: De Grondwet van de Communicatie**

De [`event_map.yaml`](config/event_map.yaml) definieert alle toegestane events en hun contracten.

### **1.6.1. V3 Event Map (5 Operators)**

| Event Naam | Payload (DTO Contract) | Mogelijke Publisher(s) | Mogelijke Subscriber(s) |
|:-----------|:-----------------------|:-----------------------|:------------------------|
| **Operation Lifecycle** | | | |
| `OperationStarted` | [`OperationParameters`](backend/dtos/state/operation_parameters.py) | Operations | EventAdapter (voor ContextOperator), ContextBootstrapper |
| `BootstrapComplete` | [`BootstrapResult`](backend/dtos/state/bootstrap_result.py) | ContextBootstrapper | ExecutionEnvironment |
| `ShutdownRequested` | [`ShutdownSignal`](backend/dtos/execution/shutdown_signal.py) | UI, EventAdapter (van ThreatWorker) | Operations |
| `OperationFinished` | [`OperationSummary`](backend/dtos/state/operation_summary.py) | Operations | ResultLogger, UI |
| --- | --- | --- | --- |
| **Tick Lifecycle (V3: 5 Operators)** | | | |
| `ContextReady` | [`TradingContext`](backend/dtos/state/trading_context.py) | ExecutionEnvironment, EventAdapter (van ContextOperator) | EventAdapter (voor OpportunityOperator, ThreatOperator) |
| `SignalsGenerated` | [`List[OpportunitySignal]`](backend/dtos/pipeline/signal.py) | EventAdapter (van OpportunityOperator) | EventAdapter (voor PlanningOperator) |
| `ThreatsDetected` | [`List[CriticalEvent]`](backend/dtos/execution/critical_event.py) | EventAdapter (van ThreatOperator) | EventAdapter (voor PlanningOperator, ExecutionOperator) |
| `PlansReady` | [`List[RoutedTradePlan]`](backend/dtos/pipeline/routed_trade_plan.py) | EventAdapter (van PlanningOperator) | EventAdapter (voor ExecutionOperator) |
| `ExecutionApproved` | [`List[ExecutionDirective]`](backend/dtos/execution/execution_directive.py) | EventAdapter (van ExecutionOperator) | ExecutionEnvironment |
| --- | --- | --- | --- |
| **State & Monitoring Lifecycle** | | | |
| `LedgerStateChanged` | [`LedgerState`](backend/dtos/state/ledger_state.py) | ExecutionEnvironment | EventAdapter (voor ThreatWorker) |
| `AggregatePortfolioUpdated` | [`AggregateMetrics`](backend/dtos/state/aggregate_metrics.py) | EventAdapter (van ThreatWorker) | UI, EventAdapter (voor ExecutionWorker) |
| --- | --- | --- | --- |
| **Analyse Lifecycle** | | | |
| `BacktestCompleted` | [`BacktestResult`](backend/dtos/state/backtest_result.py) | Operations | ResultLogger, UI |
| --- | --- | --- | --- |
| **Scheduler Events (NIEUW in V3)** | | | |
| `DAILY_MARKET_OPEN_TICK` | [`ScheduledTick`](backend/dtos/state/scheduled_tick.py) | Scheduler | EventAdapter (voor ExecutionWorker) |
| `WEEKLY_DCA_TICK` | [`ScheduledTick`](backend/dtos/state/scheduled_tick.py) | Scheduler | EventAdapter (voor OpportunityWorker, ThreatWorker) |

### **1.6.2. Operator Configuratie (operators.yaml)**

**NIEUW in V3:** Het gedrag van Operators wordt geconfigureerd via [`operators.yaml`](config/operators.yaml):

```yaml
# config/operators.yaml
operators:
  - operator_id: "ContextOperator"
    manages_worker_type: "ContextWorker"
    execution_strategy: "SEQUENTIAL"      # Workers één voor één
    aggregation_strategy: "CHAIN_THROUGH" # Output → volgende input
  
  - operator_id: "OpportunityOperator"
    manages_worker_type: "OpportunityWorker"
    execution_strategy: "PARALLEL"        # Workers tegelijkertijd
    aggregation_strategy: "COLLECT_ALL"   # Verzamel alle signalen
  
  - operator_id: "ThreatOperator"
    manages_worker_type: "ThreatWorker"
    execution_strategy: "PARALLEL"
    aggregation_strategy: "COLLECT_ALL"   # Verzamel alle threats
  
  - operator_id: "PlanningOperator"
    manages_worker_type: "PlanningWorker"
    execution_strategy: "SEQUENTIAL"
    aggregation_strategy: "CHAIN_THROUGH" # Signal → Plan transformatie
  
  - operator_id: "ExecutionOperator"
    manages_worker_type: "ExecutionWorker"
    execution_strategy: "EVENT_DRIVEN"    # Op basis van events
    aggregation_strategy: "NONE"          # Geen aggregatie
```

---

## **1.7. Event-Driven Architectuur: Drie Niveaus**

### **1.7.1. Filosofie: Progressive Complexity**

S1mpleTrader V3 omarmt het principe van **progressive complexity**: beginners kunnen simpel starten, experts krijgen alle kracht die ze nodig hebben.

### **1.7.2. Niveau 1: Impliciete Pijplijnen (95% van gebruik)**

**Voor wie:** Standaard quant die een lineaire strategie wil bouwen.

**Hoe het werkt:** De quant definieert workers, het systeem genereert automatisch de event chain.

**Voorbeeld:**

```yaml
# strategy_blueprint.yaml
workforce:
  context_workers:
    - plugin: "ema_detector"
    - plugin: "market_structure_detector"
  
  opportunity_workers:
    - plugin: "fvg_detector"
  
  planning_workers:
    entry_planning:
      - plugin: "limit_entry_planner"
    exit_planning:
      - plugin: "liquidity_target_exit"
    size_planning:
      - plugin: "fixed_risk_sizer"
    order_routing:
      - plugin: "default_router"
  
  execution_workers:
    trade_initiation:
      - plugin: "default_plan_executor"
```

**Automatisch gegenereerde event flow:**
```
ContextReady → SignalsGenerated → PlansReady → ExecutionApproved
```

**Voordelen:**
- ✅ Geen event management nodig
- ✅ Duidelijke, lineaire flow
- ✅ "Het werkt gewoon"

### **1.7.3. Niveau 2: Predefined Triggers (Opt-in)**

**Voor wie:** Quant die specifieke workers op specifieke momenten wil activeren.

**Voorbeeld:**

```yaml
workforce:
  threat_workers:
    - plugin: "max_drawdown_monitor"
      triggers:
        - "on_ledger_update"  # Predefined trigger
    
    - plugin: "news_event_monitor"
      triggers:
        - "on_context_ready"
```

**Predefined Triggers:**
- `on_context_ready`: Wanneer context klaar is
- `on_signal_generated`: Wanneer een signaal is gegenereerd
- `on_ledger_update`: Wanneer ledger verandert
- `on_position_opened`: Wanneer een positie wordt geopend
- `on_position_closed`: Wanneer een positie wordt gesloten
- `on_schedule`: Tijd-gebaseerd (via scheduler)

### **1.7.4. Niveau 3: Custom Event Chains (Expert Mode)**

**Voor wie:** Geavanceerde quant die complexe, event-driven workflows wil bouwen.

**Voorbeeld: Smart DCA**

```yaml
workforce:
  opportunity_workers:
    - plugin: "dca_opportunity_scorer"
      triggers:
        - "on_schedule:weekly_dca"
      publishes:
        - event: "dca_opportunity_scored"
          payload_type: "Signal"
  
  threat_workers:
    - plugin: "dca_risk_assessor"
      triggers:
        - "on_schedule:weekly_dca"
      publishes:
        - event: "dca_risk_assessed"
          payload_type: "CriticalEvent"
  
  planning_workers:
    entry_planning:
      - plugin: "adaptive_dca_planner"
        triggers:
          - "dca_opportunity_scored"
          - "dca_risk_assessed"
        requires_all: true  # Wacht op beide events
        publishes:
          - event: "dca_plan_ready"
            payload_type: "TradePlan"
```

**Event Flow:**
```
Scheduler → WEEKLY_DCA_TICK
         ↓
    ┌────┴────┐
    ▼         ▼
Opportunity  Threat
  Scorer    Assessor
    │         │
    ▼         ▼
dca_opportunity_scored  dca_risk_assessed
         │         │
         └────┬────┘
              ▼
      Adaptive DCA Planner
              ▼
        dca_plan_ready
```

---

## **1.8. De Operator Suite (V3)**

### **1.8.1. Van 4 naar 5 Operators**

**V2 Model (4 Operators):**
- ContextOrchestrator
- AnalysisOperator (bevatte signals + planning)
- MonitorOperator
- ExecutionHandler

**V3 Model (5 Operators):**
- [`ContextOperator`](backend/core/operators/base_operator.py) - "De Cartograaf"
- [`OpportunityOperator`](backend/core/operators/base_operator.py) - "De Verkenner" (was deel van Analysis)
- [`ThreatOperator`](backend/core/operators/base_operator.py) - "De Waakhond" (was Monitor)
- [`PlanningOperator`](backend/core/operators/base_operator.py) - "De Strateeg" (NIEUW, was deel van Analysis)
- [`ExecutionOperator`](backend/core/operators/base_operator.py) - "De Uitvoerder"

### **1.8.2. Operator Responsibilities**

| Operator | Input | Output | Execution Strategy |
|:---------|:------|:-------|:-------------------|
| **ContextOperator** | [`TradingContext`](backend/dtos/state/trading_context.py) (base) | [`TradingContext`](backend/dtos/state/trading_context.py) (verrijkt) | SEQUENTIAL |
| **OpportunityOperator** | [`TradingContext`](backend/dtos/state/trading_context.py) | [`List[OpportunitySignal]`](backend/dtos/pipeline/signal.py) | PARALLEL |
| **ThreatOperator** | [`TradingContext`](backend/dtos/state/trading_context.py), [`LedgerState`](backend/dtos/state/ledger_state.py) | [`List[CriticalEvent]`](backend/dtos/execution/critical_event.py) | PARALLEL |
| **PlanningOperator** | [`OpportunitySignal`](backend/dtos/pipeline/signal.py), [`List[CriticalEvent]`](backend/dtos/execution/critical_event.py) | [`List[RoutedTradePlan]`](backend/dtos/pipeline/routed_trade_plan.py) | SEQUENTIAL |
| **ExecutionOperator** | [`RoutedTradePlan`](backend/dtos/pipeline/routed_trade_plan.py) | [`List[ExecutionDirective]`](backend/dtos/execution/execution_directive.py) | EVENT_DRIVEN |

### **1.8.3. Data-Driven Operator Configuratie**

**KERNAFWIJKING #3A:** In plaats van 5 hard-coded operator klassen, gebruikt V3 één [`BaseOperator`](backend/core/operators/base_operator.py) met configuratie:

```python
# backend/core/operators/base_operator.py
class BaseOperator:
    """
    Generieke operator die workers orkestreert volgens configuratie.
    
    Gedrag wordt bepaald door operators.yaml, niet door code.
    """
    
    def __init__(self,
                 operator_id: str,
                 workers: List[IWorker],
                 execution_strategy: ExecutionStrategy,
                 aggregation_strategy: AggregationStrategy):
        self.operator_id = operator_id
        self.workers = workers
        self.execution_strategy = execution_strategy
        self.aggregation_strategy = aggregation_strategy
    
    def run_pipeline(self, context: TradingContext) -> Any:
        """
        Voert de worker pipeline uit volgens configured strategy.
        """
        if self.execution_strategy == ExecutionStrategy.SEQUENTIAL:
            return self._run_sequential(context)
        elif self.execution_strategy == ExecutionStrategy.PARALLEL:
            return self._run_parallel(context)
        elif self.execution_strategy == ExecutionStrategy.EVENT_DRIVEN:
            return self._run_event_driven(context)
```

---

## **Conclusie**

S1mpleTrader V3 introduceert een robuuste, flexibele en elegante communicatie-architectuur die:

✅ **Bus-agnostische plugins** - Volledige isolatie via PluginEventAdapter  
✅ **Twee-niveaus event routing** - Plugin contracts + applicatie bedrading  
✅ **Automatische event chain validatie** - Catch errors tijdens startup  
✅ **Progressive complexity** - Van simpel naar expert zonder refactoring  
✅ **5-operator model** - Duidelijke scheiding van verantwoordelijkheden  
✅ **Data-driven configuratie** - Gedrag in YAML, niet in code

Deze architectuur maakt het mogelijk om complexe, event-driven strategieën te bouwen terwijl het systeem begrijpelijk en onderhoudbaar blijft voor quants van alle niveaus.

---

**Referenties:**
- [`MIGRATION_MAP.md`](MIGRATION_MAP.md) - Volledige V2 → V3 migratie gids
- [`WORKER_TAXONOMIE_V3.md`](../development/251014%20Bijwerken%20documentatie/WORKER_TAXONOMIE_V3.md) - Uitgebreide worker taxonomie
- [`Uitwerking Kernafwijking #4A2`](../development/251014%20Bijwerken%20documentatie/Uitwerking%20Kernafwijking%20%234A2%20-%20Plugin%20Event%20Architectuur.md) - Plugin event architectuur details
- [`2_ARCHITECTURE.md`](2_ARCHITECTURE.md) - Hoofd architectuur document