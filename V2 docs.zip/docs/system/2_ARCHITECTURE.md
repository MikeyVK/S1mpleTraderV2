# 2. De Gelaagde Architectuur (Overzicht & Componenten)

De applicatie is opgebouwd uit drie strikt gescheiden lagen die een **eenrichtingsverkeer** van afhankelijkheden afdwingen (`Frontend -> Service -> Backend`). Deze structuur ontkoppelt de lagen en garandeert de herbruikbaarheid van de `Backend`.

---
## 2.1. Visueel Diagram

[Het stroomdiagram zoals eerder opgesteld wordt hier de visuele anker van het document.]

---
## 2.2. Componenten in Detail

Hieronder volgt een gedetailleerde beschrijving van elk hoofdcomponent in de architectuur.

### **2.2.1. Applicatie Entrypoint**
* [cite_start]**Plek:** Project Root (`main.py`)[cite: 4, 586].
* **Verantwoordelijkheid:** Fungeert als de "voordeur" van de applicatie. [cite_start]Parsed de command-line argumenten (zoals `mode`) en start de juiste `Service` of `Meta-Wrapper`[cite: 586, 588].
* **Input:** Command-line argumenten.
* **Proces:** Leest het `--mode` argument om te bepalen welke workflow gestart moet worden (`backtest`, `optimize`, `live`, etc.).
* **Output:** Een gestarte `Service` of `Wrapper`.

### **2.2.2. Meta-Wrappers**
* **Plek:** `Service`-laag (bv. `services/optimization_service.py`).
* **Verantwoordelijkheid:** Beheert meta-processen die meerdere runs van de `StrategyOrchestrator` vereisen.
* **Voorbeelden:** `OptimizationService`, `VariantTestService`.
* **Input:** Een basis `AppConfig` object.
* **Proces:**
    * [cite_start]**`OptimizationService`**: Genereert een grote set van `AppConfig` varianten op basis van de optimalisatie-parameters[cite: 1194]. [cite_start]Het gebruikt de `ParallelRunService` om voor elke configuratie een backtest te draaien[cite: 1195].
    * [cite_start]**`VariantTestService`**: Genereert een kleine, gedefinieerde set van `AppConfig` varianten en voert deze parallel uit[cite: 1197, 1198].
* **Output:** Een verzameling van `BacktestResult` objecten, klaar voor presentatie.

### **2.2.3. StrategyOrchestrator**
* **Plek:** `Service`-laag. Dit is de herbruikbare "strategie-motor".
* [cite_start]**Verantwoordelijkheid:** Het uitvoeren van de volledige 6-fasen trechter voor een *enkele* strategie-configuratie binnen een *specifieke* omgeving[cite: 1723]. Het is agnostisch over of het een backtest, paper of live trade is.
* **Input:** Een `AppConfig` object en een geïnitialiseerd `ExecutionEnvironment` object.
* **Proces:**
    1.  Draagt de `context_pipeline` configuratie en de ruwe data over aan de `AbstractPluginFactory` om de `enriched_df` te laten genereren.
    2.  Draagt de `strategy_pipeline` configuratie over aan de `AbstractPluginFactory` om de benodigde `StrategyWorker`-plugins te laten bouwen.
    3.  Roept de `process`-methodes van de `StrategyWorkers` in de vaste, logische volgorde van de 6 fasen aan.
    4.  Levert de finaal goedgekeurde `Trade` DTO's aan de `ExecutionHandler` binnen de actieve `ExecutionEnvironment`.
* **Output:** `BacktestResult` (in backtest-modus) of live-orders (in live-modus).

### **2.2.4. ExecutionEnvironment**
* **Plek:** `Backend`-laag.
* **Verantwoordelijkheid:** Definieert de context en de "wereld" waarin de `StrategyOrchestrator` opereert. Dit component maakt de scheiding tussen backtesting en live trading mogelijk.
* **Input:** Geen directe input; wordt geconfigureerd bij initialisatie.
* **Componenten:**
    * **`DataSource`**: Levert marktdata (uit een CSV-bestand of een live WebSocket).
    * **`Clock`**: Genereert de "hartslag" van het systeem (simuleert tijd in een backtest, volgt de echte tijd live).
    * **`ExecutionHandler`**: Voert de `Trade` DTO's uit (simuleert fills in het `Portfolio` of stuurt echte orders naar een exchange API).
* **Output:** Een stroom van marktdata-events en de uitvoering van orders.

### **2.2.5. Portfolio**
* [cite_start]**Plek:** `Backend`-laag (`backend/core/portfolio.py`)[cite: 205].
* **Verantwoordelijkheid:** Functioneert als het centrale, "domme" grootboek. Het houdt de financiële staat van het systeem bij.
* **Input:** `Order` objecten van een `ExecutionHandler`. Prijsupdates van een `DataSource`.
* **Proces:**
    * [cite_start]Houdt de cash-balans en de waarde van het portfolio bij[cite: 205, 206].
    * [cite_start]Registreert openstaande orders en actieve posities, idealiter per strategie (`strategy_id`)[cite: 792].
    * Verwerkt "fills" wanneer de marktprijs een openstaande order raakt.
    * Berekent winst en verlies op gesloten posities.
* [cite_start]**Output:** Een continu bijgewerkte staat van de portfolio-waarde (`equity curve`) en een lijst van gesloten trades (`ClosedTrade` DTO's)[cite: 208, 273].

### **2.2.6. AbstractPluginFactory**
* **Plek:** `Backend`-laag.
* **Verantwoordelijkheid:** Het ontdekken, valideren, bouwen en technisch orkestreren van alle plugins. Het is de motor achter de `StrategyOrchestrator`.
* **Input:** De `context_pipeline` en `strategy_pipeline` secties van de `AppConfig`. Een ruwe `DataFrame`.
* **Proces:**
    1.  **Discovery:** Scant de `plugins/` map en bouwt een register van alle beschikbare plugins op basis van hun manifest.
    2.  **Orkestratie van Context:** Voert de `context_pipeline` uit, inclusief de parallelle executie van workers binnen een groep en de seriële executie van de groepen.
    3.  **Constructie:** Bouwt op aanvraag instanties van de `StrategyWorker`-plugins.
* **Output:** Een `enriched_df` en geïnstantieerde `worker`-objecten.

### **2.2.7. Plugins**
* **Plek:** `plugins/`-map.
* **Verantwoordelijkheid:** Bevatten alle specifieke, modulaire logica voor contextverrijking en strategie-executie. Elke plugin is een zelfstandige, testbare eenheid.
* **Input:** Een `DataFrame` (voor `ContextWorkers`) of `DTO`'s (voor `StrategyWorkers`).
* **Proces:** Voert zijn specifieke taak uit (bv. een `RSI` berekenen, een `FVG` detecteren, een `Stop-Loss` bepalen).
* **Output:** Een verrijkte `DataFrame` of nieuwe/aangepaste `DTO`'s.