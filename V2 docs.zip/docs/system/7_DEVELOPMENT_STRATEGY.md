# 7. Ontwikkelstrategie & Tooling in V2

Dit document beschrijft de methodiek voor het ontwikkelen, testen en debuggen van het S1mpleTrader V2 ecosysteem. Het doel is een snelle, efficiënte en robuuste workflow te creëren die integraal onderdeel is van het project.

### 7.1. Filosofie: Rapid & Lean Development

We stappen af van een traditionele, op `stdio` gerichte workflow. De nieuwe filosofie is gebaseerd op:

* **Compact Ontwikkelen:** Ontwikkel de kleinst mogelijke, onafhankelijke eenheid (een plugin) en test deze geïsoleerd.
* **Direct Testen:** Elke plugin wordt vergezeld van een unit test. Geen enkele plugin wordt als "klaar" beschouwd zonder een succesvolle test.
* **Snelle Feedback Loop:** De tijd tussen een codewijziging en het zien van het resultaat moet minimaal zijn. De primaire interface voor deze feedback is niet de CLI, maar een speciaal ontwikkelde web-frontend.

### 7.2. Een Gelaagde Aanpak voor Logging & Presentatie

Logging is niet één ding, maar een tool met verschillende doelen in verschillende omgevingen. We onderscheiden drie lagen:

1.  **Laag 1: `stdio` (De Console)**
    * **Doel:** Alleen voor *initiële, basic development* van een geïsoleerde plugin en voor het monitoren van de *gezondheid* van het live-systeem (bv. "Supervisor gestart", "Verbinding met exchange OK").
    * **Gebruik:** De `print()`-functie of een simpele `logging.StreamHandler`. Dit is voor de snelle, "vuile" check tijdens het schrijven van een worker.

2.  **Laag 2: Gestructureerde Logs (`JSON`)**
    * **Doel:** De primaire output voor **backtests, optimalisaties en paper trading**. Dit is de databron voor analyse en debugging.
    * **Implementatie:** Een `logging.FileHandler` die log-records als gestructureerde `JSON`-objecten wegschrijft. Elk record bevat de `Correlation ID`, `plugin_name`, `timestamp`, en de log-data.
    * **Principe:** De console blijft schoon tijdens een backtest. De *echte* output is het `run.log.json` bestand.

3.  **Laag 3: De Web Frontend (De Analyse Hub)**
    * **Doel:** De primaire interface voor **configuratie, analyse en visualisatie**.
    * **Implementatie:** Een lokale webserver (`FastAPI` is hier perfect voor) die de gestructureerde `JSON`-logs kan inlezen en interactief kan presenteren.

### 7.3. De Web Frontend als Primair Development Tool

De grootste efficiëntieslag wordt gemaakt door de frontend niet te zien als iets "voor later", maar als een **essentieel development tool**.

* **Dynamische Plugin-Configuratie:** Zoals besproken, bouwt de web-UI dynamisch de configuratie-schermen op basis van de `plugin_manifest.yaml` en `schema.py` van de plugins. Het aanpassen van parameters gebeurt in een webformulier, niet door handmatig `YAML` te editen.
* **Interactieve Log-Analyse:** De frontend krijgt een "Log Explorer" die `run.log.json` inleest. Hiermee kun je:
    * Filteren op `plugin_name`.
    * De volledige levenscyclus van één trade volgen door te filteren op `Correlation ID`.
    * Log-berichten van parallelle processen gescheiden en geordend bekijken.
* **Directe Visualisatie:** Na een backtest kan de UI direct de resultaten (`result_metrics.yaml`, `trades.csv`) en de context-visualisaties tonen zonder de CLI te verlaten.

### 7.4. Testen als Integraal Onderdeel

De "Direct Testen" filosofie wordt concreet gemaakt met de volgende aanpak:

* **Unit Tests per Plugin:** Elke plugin-map krijgt een `test_worker.py`. Deze test laadt een stukje voorbeeld-data, draait de `worker.py` erop, en valideert of de output (de nieuwe kolom of de `Signal` DTO) correct is. Dit gebeurt volledig geïsoleerd.
* **Integratietests voor de Orchestrator:** We creëren tests die een minimale `YAML`-configuratie met 2-3 plugins laden en valideren of de `StrategyOrchestrator` de data correct doorgeeft van de ene fase naar de andere.
* **End-to-End Tests:** Een klein aantal tests die een volledige backtest-run uitvoeren op een kleine, vaste dataset en controleren of het eindresultaat (de PnL) exact overeenkomt met een vooraf berekende waarde. Dit vangt onverwachte regressies op.

Door deze strategie te formaliseren, veranderen we de workflow van een comfortabele maar inefficiënte cyclus naar een moderne, snelle en data-gedreven ontwikkelomgeving.